-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 09, 2019 at 06:53 PM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `penggajian_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `absensi`
--

CREATE TABLE `absensi` (
  `no_absensi` varchar(12) NOT NULL,
  `nip` int(5) NOT NULL,
  `periode` int(6) NOT NULL,
  `nama_karyawan` varchar(30) NOT NULL,
  `jabatan` varchar(25) NOT NULL,
  `total_masuk` int(2) NOT NULL,
  `total_absen` int(2) NOT NULL,
  `total_telat` int(2) NOT NULL,
  `total_izin` int(2) NOT NULL,
  `total_lembur` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `absensi`
--

INSERT INTO `absensi` (`no_absensi`, `nip`, `periode`, `nama_karyawan`, `jabatan`, `total_masuk`, `total_absen`, `total_telat`, `total_izin`, `total_lembur`) VALUES
('101-201801', 101, 201801, 'Baihirul Fuat', 'Direktur Utama', 22, 0, 0, 0, 0),
('101-201802', 101, 201802, 'Baihirul Fuat', 'Direktur Utama', 22, 0, 0, 0, 60),
('101-201909', 101, 201909, 'Baihirul Fuat', 'Direktur Utama', 21, 1, 10, 0, 120),
('102-201801', 102, 201801, 'Haerul Kamal', 'General Manager', 22, 0, 0, 0, 0),
('102-201802', 102, 201802, 'Haerul Kamal', 'General Manager', 22, 0, 0, 0, 100),
('103-201801', 103, 201801, 'Bagus Gradianto', 'Kepala HRD', 21, 1, 110, 0, 0),
('103-201802', 103, 201802, 'Bagus Gradianto', 'Kepala HRD', 20, 1, 0, 1, 80),
('104-201801', 104, 201801, 'Elfansyah Bagus Lutfiantoro', 'Manager Marketing', 21, 0, 200, 1, 120),
('104-201802', 104, 201802, 'Elfansyah Bagus Lutfiantoro', 'Manager Marketing', 22, 0, 10, 0, 45),
('105-201801', 105, 201801, 'Harmono', 'Manager Produksi', 20, 1, 320, 1, 60),
('105-201802', 105, 201802, 'Harmono', 'Manager Produksi', 22, 0, 20, 0, 75),
('106-201801', 106, 201801, 'Megiyanto', 'Manager Personalia', 22, 0, 0, 0, 0),
('106-201802', 106, 201802, 'Megiyanto', 'Manager Personalia', 22, 0, 30, 0, 90),
('107-201801', 107, 201801, 'Andi', 'Security', 21, 1, 1000, 0, 120),
('107-201802', 107, 201802, 'Andi', 'Security', 22, 0, 0, 0, 400),
('108-201801', 108, 201801, 'Budi', 'Staf Produksi 1', 22, 0, 135, 0, 240),
('108-201802', 108, 201802, 'Budi', 'Staf Produksi 1', 22, 0, 100, 0, 290),
('109-201801', 109, 201801, 'Tono', 'Staf Produksi 1', 18, 2, 190, 2, 45),
('109-201802', 109, 201802, 'Tono', 'Staf Produksi 1', 22, 0, 15, 0, 90),
('110-201801', 110, 201801, 'Alicia', 'Sekretaris', 22, 0, 0, 0, 360),
('110-201802', 110, 201802, 'Alicia', 'Sekretaris', 22, 0, 0, 0, 700),
('111-201801', 111, 201801, 'Trisha', 'Staf HRD', 22, 0, 0, 0, 0),
('111-201802', 111, 201802, 'Trisha', 'Staf HRD', 22, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `gaji`
--

CREATE TABLE `gaji` (
  `kd_jabatan` varchar(6) NOT NULL,
  `nama_jabatan` varchar(25) NOT NULL,
  `gaji_pokok` varchar(15) NOT NULL,
  `tj_jabatan` varchar(15) NOT NULL,
  `tj_keluarga` varchar(15) NOT NULL,
  `uang_makan` varchar(15) NOT NULL,
  `lembur` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gaji`
--

INSERT INTO `gaji` (`kd_jabatan`, `nama_jabatan`, `gaji_pokok`, `tj_jabatan`, `tj_keluarga`, `uang_makan`, `lembur`) VALUES
('DIR001', 'Direktur Utama', '20000000', '10000000', '5000000', '83500', '1500'),
('GNM001', 'General Manager', '8000000', '4000000', '1500000', '58500', '560'),
('KPG001', 'Kepala Gudang', '3500000', '1000000', '300000', '30000', '250'),
('KPH001', 'Kepala HRD', '6000000', '3000000', '1000000', '41700', '440'),
('MKU001', 'Manager Keuangan', '6000000', '3000000', '1000000', '41700', '440'),
('MMA001', 'Manager Marketing', '6000000', '3000000', '1000000', '41700', '440'),
('MPE001', 'Manager Personalia', '6000000', '3000000', '1000000', '41700', '440'),
('MPR001', 'Manager Produksi', '6000000', '3000000', '1000000', '41700', '440'),
('SCR001', 'Sekretaris', '4000000', '1000000', '600000', '26700', '280'),
('SPK001', 'Supervisor Keuangan', '3500000', '700000', '400000', '26700', '250'),
('SPM001', 'Supervisor Marketing', '3500000', '700000', '400000', '26700', '250'),
('SPP001', 'Supervisor Produksi', '3500000', '700000', '400000', '26700', '250'),
('STG001', 'Staf Gudang', '2300000', '700000', '200000', '20000', '160'),
('STH001', 'Staf HRD', '2300000', '700000', '200000', '20000', '160'),
('STK001', 'Staf Keuangan', '2300000', '700000', '200000', '20000', '160'),
('STM001', 'Staf Marketing 1', '2300000', '700000', '200000', '20000', '160'),
('STM002', 'Staf Marketing 2', '2300000', '700000', '200000', '20000', '160'),
('STP001', 'Staf Produksi 1', '2300000', '700000', '200000', '20000', '160'),
('STP002', 'Staf Produksi 2', '2300000', '700000', '200000', '20000', '160'),
('STP003', 'Staf Produksi 3', '2300000', '700000', '200000', '20000', '160'),
('STP004', 'Staf Produksi 4', '2300000', '700000', '200000', '20000', '160'),
('STY001', 'Security', '2300000', '700000', '200000', '20000', '160');

-- --------------------------------------------------------

--
-- Table structure for table `karyawan`
--

CREATE TABLE `karyawan` (
  `nip` int(5) NOT NULL,
  `nama_karyawan` varchar(30) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  `tempat_lahir` varchar(20) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `pendidikan_akhir` varchar(20) NOT NULL,
  `agama` varchar(20) NOT NULL,
  `jabatan` varchar(25) NOT NULL,
  `tgl_masuk` date NOT NULL,
  `status_pernikahan` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `karyawan`
--

INSERT INTO `karyawan` (`nip`, `nama_karyawan`, `alamat`, `no_telp`, `tempat_lahir`, `tgl_lahir`, `jenis_kelamin`, `pendidikan_akhir`, `agama`, `jabatan`, `tgl_masuk`, `status_pernikahan`) VALUES
(101, 'Baihirul Fuat', 'Cengkareng', '081906054775', 'Jakarta', '1996-02-01', 'Laki-laki', 'SMA/SMK', 'Islam', 'Direktur Utama', '2018-04-01', 'Belum Menikah'),
(102, 'Haerul Kamal', 'Grogol', '089512345678', 'Bogor', '1996-04-06', 'Laki-laki', 'SMA/SMK', 'Islam', 'General Manager', '2018-04-01', 'Belum Menikah'),
(103, 'Bagus Gradianto', 'Cipondoh', '081269696969', 'Jakarta', '1997-04-17', 'Laki-laki', 'SMA/SMK', 'Islam', 'Kepala HRD', '2018-04-15', 'Belum Menikah'),
(104, 'Elfansyah Bagus Lutfiantoro', 'Dadap', '089587654321', 'Ngawi', '1996-04-02', 'Laki-laki', 'SMA/SMK', 'Islam', 'Manager Marketing', '2018-04-01', 'Belum Menikah'),
(105, 'Harmono', 'Kapuk', '081701928374', 'Madiun', '1994-04-01', 'Laki-laki', 'SMA/SMK', 'Islam', 'Manager Produksi', '2018-04-01', 'Belum Menikah'),
(106, 'Megiyanto', 'Kebon Jeruk', '085612348765', 'Jakarta', '1990-04-10', 'Laki-laki', 'SMA/SMK', 'Islam', 'Manager Personalia', '2018-04-02', 'Belum Menikah'),
(107, 'Andi', 'Cengkareng', '08122222', 'Jakarta', '1996-04-20', 'Laki-laki', 'D3', 'Islam', 'Security', '2018-04-02', 'Menikah'),
(108, 'Budi', 'Rawa Lele', '0812987987', 'Jakarta', '1998-05-09', 'Laki-laki', 'Tidak Ada', 'Islam', 'Staf Produksi 1', '2018-05-17', 'Menikah'),
(109, 'Tono', 'Rawa Lele', '0856122345', 'Jakarta', '1993-05-07', 'Laki-laki', 'SMA/SMK', 'Islam', 'Staf Produksi 1', '2018-05-17', 'Menikah'),
(110, 'Alicia', 'Kebon Jeruk', '08122933987', 'Berlin', '1997-06-01', 'Perempuan', 'S1', 'Islam', 'Sekretaris', '2018-06-03', 'Belum Menikah'),
(111, 'Trisha', 'Pesing\r\n', '0897883321', 'Jakarta', '1994-07-02', 'Perempuan', 'SMA/SMK', 'Islam', 'Staf HRD', '2018-06-01', 'Belum Menikah'),
(112, 'Diana', 'Cengkareng', '0811', 'Jakarta', '1995-09-02', 'Perempuan', 'SMA/SMK', 'Islam', 'Staf Produksi 4', '2019-08-01', 'Belum Menikah');

-- --------------------------------------------------------

--
-- Table structure for table `potongan`
--

CREATE TABLE `potongan` (
  `kd_jabatan` varchar(6) NOT NULL,
  `nama_jabatan` varchar(25) NOT NULL,
  `pot_telat` varchar(15) NOT NULL,
  `pot_absen` varchar(15) NOT NULL,
  `pot_pph21` varchar(15) NOT NULL,
  `pot_bpjs` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `potongan`
--

INSERT INTO `potongan` (`kd_jabatan`, `nama_jabatan`, `pot_telat`, `pot_absen`, `pot_pph21`, `pot_bpjs`) VALUES
('DIR001', 'Direktur Utama', '1400', '666000', '1300000', '900000'),
('GNM001', 'General Manager', '530', '266000', '409375', '360000'),
('KPG001', 'Kepala Gudang', '230', '116000', '12750', '135000'),
('KPH001', 'Kepala HRD', '400', '200000', '243125', '270000'),
('MKU001', 'Manager Keuangan', '400', '200000', '243125', '270000'),
('MMA001', 'Manager Marketing', '400', '200000', '243125', '270000'),
('MPE001', 'Manager Personalia', '400', '200000', '243125', '270000'),
('MPR001', 'Manager Produksi', '400', '200000', '243125', '270000'),
('SCR001', 'Sekretaris', '260', '133000', '31750', '150000'),
('SPK001', 'Supervisor Keuangan', '230', '116000', '12500', '126000'),
('SPM001', 'Supervisor Marketing', '230', '116000', '12500', '126000'),
('SPP001', 'Supervisor Produksi', '230', '116000', '12500', '126000'),
('STG001', 'Staf Gudang', '150', '76000', '0', '90000'),
('STH001', 'Staf HRD', '150', '76000', '0', '90000'),
('STK001', 'Staf Keuangan', '150', '76000', '0', '90000'),
('STM001', 'Staf Marketing 1', '150', '76000', '0', '90000'),
('STM002', 'Staf Marketing 2', '150', '76000', '0', '90000'),
('STP001', 'Staf Produksi 1', '150', '76000', '0', '90000'),
('STP002', 'Staf Produksi 2', '150', '76000', '0', '90000'),
('STP003', 'Staf Produksi 3', '150', '76000', '0', '90000'),
('STP004', 'Staf Produksi 4', '150', '76000', '0', '90000'),
('STY001', 'Security', '150', '76000', '0', '90000');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `no_slip` varchar(20) NOT NULL,
  `tgl_slip` date NOT NULL,
  `periode` varchar(20) NOT NULL,
  `kd_user` varchar(6) NOT NULL,
  `nip` int(5) NOT NULL,
  `nama_karyawan` varchar(30) NOT NULL,
  `jabatan` varchar(25) NOT NULL,
  `status_pernikahan` varchar(15) NOT NULL,
  `total_masuk` int(2) NOT NULL,
  `total_absen` int(2) NOT NULL,
  `total_telat` int(10) NOT NULL,
  `total_izin` int(2) NOT NULL,
  `total_lembur` int(10) NOT NULL,
  `gaji_pokok` varchar(15) NOT NULL,
  `tj_jabatan` varchar(15) NOT NULL,
  `tj_keluarga` varchar(15) NOT NULL,
  `uang_makan` varchar(15) NOT NULL,
  `uang_lembur` varchar(15) NOT NULL,
  `pot_telat` varchar(15) NOT NULL,
  `pot_absen` varchar(15) NOT NULL,
  `pot_pph21` varchar(15) NOT NULL,
  `pot_bpjs` varchar(15) NOT NULL,
  `pot_lain` varchar(15) NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  `total_pendapatan` varchar(15) NOT NULL,
  `total_potongan` varchar(15) NOT NULL,
  `jumlah_gaji` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`no_slip`, `tgl_slip`, `periode`, `kd_user`, `nip`, `nama_karyawan`, `jabatan`, `status_pernikahan`, `total_masuk`, `total_absen`, `total_telat`, `total_izin`, `total_lembur`, `gaji_pokok`, `tj_jabatan`, `tj_keluarga`, `uang_makan`, `uang_lembur`, `pot_telat`, `pot_absen`, `pot_pph21`, `pot_bpjs`, `pot_lain`, `keterangan`, `total_pendapatan`, `total_potongan`, `jumlah_gaji`) VALUES
('SL-1011806201801', '2018-06-25', '201801', 'BAI', 101, 'Baihirul Fuat', 'Direktur Utama', 'Belum Menikah', 22, 0, 0, 0, 0, '20000000', '10000000', '0', '1837000', '0', '0', '0', '1300000', '900000', '0', '', '31837000', '2200000', '29637000'),
('SL-1011909201909', '2019-09-28', '201909', 'HEL', 101, 'Baihirul Fuat', 'Direktur Utama', 'Belum Menikah', 21, 1, 10, 0, 120, '20000000', '10000000', '0', '1753500', '168000', '13500', '666000', '1300000', '900000', '0', '', '31921500', '2879500', '29042000'),
('SL-1021806201801', '2018-06-25', '201801', 'BAI', 102, 'Haerul Kamal', 'General Manager', 'Belum Menikah', 22, 0, 0, 0, 0, '8000000', '4000000', '0', '1287000', '0', '0', '0', '409375', '360000', '0', '', '13287000', '769375', '12517625'),
('SL-1031806201801', '2018-06-25', '201801', 'BAI', 103, 'Bagus Gradianto', 'Kepala HRD', 'Belum Menikah', 21, 1, 110, 0, 0, '6000000', '3000000', '0', '875700', '0', '44000', '200000', '243125', '270000', '0', '', '9875700', '757125', '9118575'),
('SL-1041806201801', '2018-06-25', '201801', 'BAI', 104, 'Elfansyah Bagus Lutfiantoro', 'Manager Marketing', 'Belum Menikah', 21, 0, 200, 1, 120, '6000000', '3000000', '0', '875700', '52800', '80000', '0', '243125', '270000', '0', '', '9928500', '593125', '9335375'),
('SL-1051806201801', '2018-06-25', '201801', 'BAI', 105, 'Harmono', 'Manager Produksi', 'Belum Menikah', 20, 1, 320, 1, 60, '6000000', '3000000', '0', '834000', '26400', '128000', '200000', '243125', '270000', '1000000', 'Bayar hutang', '9860400', '1841125', '8019275'),
('SL-1061807201801', '2018-07-02', '201801', 'BAI', 106, 'Megiyanto', 'Manager Personalia', 'Belum Menikah', 22, 0, 0, 0, 0, '6000000', '3000000', '0', '917400', '0', '0', '0', '243125', '270000', '0', '', '9917400', '513125', '9404275'),
('SL-1071806201801', '2018-06-29', '201801', 'BAI', 107, 'Andi', 'Security', 'Menikah', 21, 1, 1000, 0, 120, '2300000', '700000', '200000', '420000', '19200', '150000', '76000', '0', '90000', '0', '', '3639200', '316000', '3323200'),
('SL-1081807201801', '2018-07-02', '201801', 'BAI', 108, 'Budi', 'Staf Produksi 1', 'Menikah', 22, 0, 135, 0, 240, '2300000', '700000', '200000', '440000', '38400', '20250', '0', '0', '90000', '0', '', '3678400', '110250', '3568150'),
('SL-1091807201801', '2018-07-02', '201801', 'BAI', 109, 'Tono', 'Staf Produksi 1', 'Menikah', 18, 2, 190, 2, 45, '2300000', '700000', '200000', '360000', '7200', '28500', '152000', '0', '90000', '200000', 'Bayar hutang', '3567200', '470500', '3096700'),
('SL-1101807201801', '2018-07-02', '201801', 'BAI', 110, 'Alicia', 'Sekretaris', 'Belum Menikah', 22, 0, 0, 0, 360, '4000000', '1000000', '0', '587400', '100800', '0', '0', '31750', '150000', '0', '', '5688200', '181750', '5506450'),
('SL-1111807201801', '2018-07-02', '201801', 'BAI', 111, 'Trisha', 'Staf HRD', 'Belum Menikah', 22, 0, 0, 0, 0, '2300000', '700000', '0', '440000', '0', '0', '0', '0', '90000', '0', '', '3440000', '90000', '3350000');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `kd_user` varchar(6) NOT NULL,
  `nama_user` varchar(25) NOT NULL,
  `password` varchar(15) NOT NULL,
  `level` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`kd_user`, `nama_user`, `password`, `level`) VALUES
('BAG', 'Bagus Gradianto', 'khilaf', '2'),
('BAI', 'Baihirul Fuat', '12345', '1'),
('ELF', 'Elfansyah Bagus', 'dedek', '2'),
('HAE', 'Haerul Kamal', 'balabala', '2'),
('HAR', 'Harmono', 'donwori', '2'),
('HEL', 'Helena', '1234', '2'),
('MEG', 'Megiyanto', 'donjuan', '2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `absensi`
--
ALTER TABLE `absensi`
  ADD PRIMARY KEY (`no_absensi`);

--
-- Indexes for table `gaji`
--
ALTER TABLE `gaji`
  ADD PRIMARY KEY (`kd_jabatan`);

--
-- Indexes for table `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`nip`);

--
-- Indexes for table `potongan`
--
ALTER TABLE `potongan`
  ADD PRIMARY KEY (`kd_jabatan`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`no_slip`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`kd_user`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
