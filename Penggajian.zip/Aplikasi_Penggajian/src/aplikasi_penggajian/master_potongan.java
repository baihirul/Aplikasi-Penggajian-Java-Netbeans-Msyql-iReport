/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplikasi_penggajian;
import java.awt.event.KeyEvent;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Baihirul Fuat
 */
public class master_potongan extends javax.swing.JFrame {
koneksi kon = new koneksi();
private Object [][] datapotongan=null;
private String[] label={"Kode Jabatan","Nama Jabatan","Potongan Telat","Potongan Absen","Potongan PPh 21","Potongan BPJS"};
    /**
     * Creates new form master_potongan
     */
    public master_potongan() {
        initComponents();
        kon.setKoneksi();
        BacaTabelPotongan();
    }
    
    public String KodeJabatan;
    public String NamaJabatan;
        public String getKodeJabatan(){
            return KodeJabatan;
        }
        public String getNamaJabatan(){
            return NamaJabatan;
        }
    
    private void BacaTabelPotongan(){
        try{
            String sql="select * from potongan order by kd_jabatan";
            kon.rs=kon.st.executeQuery(sql);
            ResultSetMetaData m=kon.rs.getMetaData();
            int kolom=m.getColumnCount();
            int baris=0;
            while(kon.rs.next()){
                baris=kon.rs.getRow();
            }
            datapotongan=new Object[baris][kolom];
            int x=0;
            kon.rs.beforeFirst();
            while(kon.rs.next()){
                datapotongan[x][0]=kon.rs.getString("kd_jabatan");
                datapotongan[x][1]=kon.rs.getString("nama_jabatan");
                datapotongan[x][2]=kon.rs.getString("pot_telat");
                datapotongan[x][3]=kon.rs.getString("pot_absen");
                datapotongan[x][4]=kon.rs.getString("pot_pph21");
                datapotongan[x][5]=kon.rs.getString("pot_bpjs");
                x++;
            }
            tbpotongan.setModel(new DefaultTableModel(datapotongan,label));
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void BacaTabelPotonganCari(){
        try{
            String sql="select * from potongan where nama_jabatan like '%" +tcari.getText()+ "%'";
            kon.rs=kon.st.executeQuery(sql);
            ResultSetMetaData m=kon.rs.getMetaData();
            int kolom=m.getColumnCount();
            int baris=0;
            while(kon.rs.next()){
                baris=kon.rs.getRow();
            }
            datapotongan=new Object[baris][kolom];
            int x=0;
            kon.rs.beforeFirst();
            while(kon.rs.next()){
                datapotongan[x][0]=kon.rs.getString("kd_jabatan");
                datapotongan[x][1]=kon.rs.getString("nama_jabatan");
                datapotongan[x][2]=kon.rs.getString("pot_telat");
                datapotongan[x][3]=kon.rs.getString("pot_absen");
                datapotongan[x][4]=kon.rs.getString("pot_pph21");
                datapotongan[x][5]=kon.rs.getString("pot_bpjs");
                x++;
            }
            tbpotongan.setModel(new DefaultTableModel(datapotongan,label));
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void SetTabel(){
        int row=tbpotongan.getSelectedRow();
        tkode.setText((String)tbpotongan.getValueAt(row, 0));
        tnama.setText((String)tbpotongan.getValueAt(row, 1));
        ttelat.setText((String)tbpotongan.getValueAt(row, 2));
        tabsen.setText((String)tbpotongan.getValueAt(row, 3));
        tpph.setText((String)tbpotongan.getValueAt(row, 4));
        tbpjs.setText((String)tbpotongan.getValueAt(row, 5));
    }
    
    private void bersih(){
        tkode.setText("");
        tnama.setText("");
        ttelat.setText("");
        tabsen.setText("");
        tpph.setText("");
        tbpjs.setText("");
    }
    
    private void aktif(){
        ttelat.setEnabled(true);
        tabsen.setEnabled(true);
        tpph.setEnabled(true);
        tbpjs.setEnabled(true);
        btbrowse.setEnabled(true);
    }
    
    private void nonaktif(){
        tkode.setEnabled(false);
        tnama.setEnabled(false);
        ttelat.setEnabled(false);
        tabsen.setEnabled(false);
        tpph.setEnabled(false);
        tbpjs.setEnabled(false);
        btbrowse.setEnabled(false);
    }
    
    private void SimpanData(){
            if(tkode.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Kode Jabatan Tidak Boleh Kosong");
            }
            else if(tnama.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Nama Jabatan Tidak Boleh Kosong");
            }
            else if(ttelat.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Potongan Telat Tidak Boleh Kosong");
            }
            else if(tabsen.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Potongan Absen Tidak Boleh Kosong");
            }
            else if(tpph.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Potongan PPh 21 Tidak Boleh Kosong");
            }
            else if(tbpjs.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Potongan BPJS Tidak Boleh Kosong");
            }
            else{
                try{
                    String sql="insert into potongan values('"+tkode.getText()+"','"+tnama.getText()+"','"+ttelat.getText()+"','"+tabsen.getText()+"','"+tpph.getText()+"','"+tbpjs.getText()+"')";
                    kon.st.executeUpdate(sql);
                    JOptionPane.showMessageDialog(null,"Data berhasil disimpan");
                    bttambah.setText("TAMBAH");
                    btkeluar.setText("KELUAR");
                    bersih();
                    nonaktif();
                    BacaTabelPotongan();
                }
                catch(SQLException e){
                    JOptionPane.showMessageDialog(null, e);
                }
            }
    }
    
    private void UpdateData(){
            if(tkode.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Kode Jabatan Tidak Boleh Kosong");
            }
            else if(tnama.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Nama Jabatan Tidak Boleh Kosong");
            }
            else if(ttelat.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Potongan Telat Tidak Boleh Kosong");
            }
            else if(tabsen.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Potongan Absen Tidak Boleh Kosong");
            }
            else if(tpph.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Potongan PPh 21 Tidak Boleh Kosong");
            }
            else if(tbpjs.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Potongan BPJS Tidak Boleh Kosong");
            }
            else{
                try{
                    String sql="update potongan set kd_jabatan='"+tkode.getText()+"',nama_jabatan='"+tnama.getText()+"',pot_telat='"+ttelat.getText()+"',pot_absen='"+tabsen.getText()+"',pot_pph21='"+tpph.getText()+"',pot_bpjs='"+tbpjs.getText()+"' where kd_jabatan='"+tkode.getText()+"'";
                    kon.st.executeUpdate(sql);
                    JOptionPane.showMessageDialog(null,"Data berhasil diedit");
                    bttambah.setText("TAMBAH");
                    btkeluar.setText("KELUAR");
                    bersih();
                    nonaktif();
                    BacaTabelPotongan();
                }
                catch(SQLException e){
                    JOptionPane.showMessageDialog(null, e);
                }
            }
    }
    
    private void HapusData(){
        if(JOptionPane.showConfirmDialog(this,"Yakin ingin menghapus data?","Konfirmasi",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
            try{
                String sql="delete from potongan where kd_jabatan='"+tkode.getText()+"'";
                kon.st.executeUpdate(sql);
                JOptionPane.showMessageDialog(null,"Data berhasil dihapus");
                bersih();
                BacaTabelPotongan();
            }
            catch(SQLException e){
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpop = new javax.swing.JPopupMenu();
        miedit = new javax.swing.JMenuItem();
        mihapus = new javax.swing.JMenuItem();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        ttelat = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        tkode = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        tnama = new javax.swing.JTextField();
        tabsen = new javax.swing.JTextField();
        btbrowse = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        tpph = new javax.swing.JTextField();
        tbpjs = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        tcari = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbpotongan = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        bttambah = new javax.swing.JButton();
        btkeluar = new javax.swing.JButton();

        miedit.setText("Edit");
        miedit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mieditActionPerformed(evt);
            }
        });
        jpop.add(miedit);

        mihapus.setText("Hapus");
        mihapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mihapusActionPerformed(evt);
            }
        });
        jpop.add(mihapus);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Master Potongan");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jPanel5.setBackground(new java.awt.Color(43, 203, 186));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("INPUT DATA POTONGAN");

        jPanel6.setBackground(new java.awt.Color(43, 203, 186));
        jPanel6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jPanel2.setBackground(new java.awt.Color(43, 203, 186));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Data Potongan"));

        jLabel4.setText("Kode Jabatan");

        ttelat.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                ttelatKeyPressed(evt);
            }
        });

        jLabel5.setText("Nama Jabatan");

        tkode.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tkodeKeyPressed(evt);
            }
        });

        jLabel6.setText("Potongan Telat");

        jLabel7.setText("Potongan Absen");

        tnama.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tnamaKeyPressed(evt);
            }
        });

        tabsen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tabsenKeyPressed(evt);
            }
        });

        btbrowse.setText("...");
        btbrowse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btbrowseActionPerformed(evt);
            }
        });

        jLabel8.setText("Potongan PPh 21");

        jLabel9.setText("Potongan BPJS");

        tpph.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tpphKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4))
                        .addGap(30, 30, 30)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(tkode, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btbrowse, javax.swing.GroupLayout.PREFERRED_SIZE, 32, Short.MAX_VALUE))
                            .addComponent(ttelat)
                            .addComponent(tnama)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9)
                            .addComponent(jLabel7))
                        .addGap(21, 21, 21)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tpph, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(tabsen)
                            .addComponent(tbpjs))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(tkode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btbrowse))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tnama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ttelat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tabsen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tpph, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tbpjs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("TABEL DATA POTONGAN");

        jPanel1.setBackground(new java.awt.Color(43, 203, 186));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jLabel2.setText("Cari Nama Jabatan");

        tcari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tcariKeyTyped(evt);
            }
        });

        tbpotongan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbpotongan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbpotonganMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                tbpotonganMouseReleased(evt);
            }
        });
        tbpotongan.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tbpotonganKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(tbpotongan);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 960, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(tcari, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(tcari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 467, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel3.setBackground(new java.awt.Color(43, 203, 186));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        bttambah.setText("TAMBAH");
        bttambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttambahActionPerformed(evt);
            }
        });

        btkeluar.setText("KELUAR");
        btkeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btkeluarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bttambah)
                .addGap(18, 18, 18)
                .addComponent(btkeluar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bttambah)
                    .addComponent(btkeluar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(51, 51, 51)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(156, 156, 156)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bttambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttambahActionPerformed
    if(bttambah.getText().equals("TAMBAH")){
        bttambah.setEnabled(false);
        bttambah.setText("SIMPAN");
        btkeluar.setText("BATAL");
        bersih();
        aktif();
        tkode.requestFocus();
    }
    else if(bttambah.getText().equals("SIMPAN")){
        SimpanData();
        BacaTabelPotongan();
    }
    else if(bttambah.getText().equals("UPDATE")){
        UpdateData();
        BacaTabelPotongan();
    }
    }//GEN-LAST:event_bttambahActionPerformed

    private void btkeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btkeluarActionPerformed
    if(btkeluar.getText().equals("KELUAR")){
        dispose();
    }
    else if(btkeluar.getText().equals("BATAL")){
        bersih();
        nonaktif();
        btkeluar.setText("KELUAR");
        bttambah.setText("TAMBAH");
    }
    }//GEN-LAST:event_btkeluarActionPerformed

    private void tkodeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tkodeKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        try{
            String sql="select * from potongan where kd_jabatan='"+tkode.getText()+"'";
            kon.rs=kon.st.executeQuery(sql);
            if(kon.rs.next()){
                tkode.setEnabled(false);
                tnama.setEnabled(false);
                btbrowse.setEnabled(false);
                tkode.setText(kon.rs.getString("kd_jabatan"));
                tnama.setText(kon.rs.getString("nama_jabatan"));
                ttelat.setText(kon.rs.getString("pot_telat"));
                tabsen.setText(kon.rs.getString("pot_absen"));
                tpph.setText(kon.rs.getString("pot_pph21"));
                tbpjs.setText(kon.rs.getString("pot_bpjs"));
                bttambah.setText("UPDATE");
            } else{
                tnama.requestFocus();
            }
        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    }//GEN-LAST:event_tkodeKeyPressed

    private void tcariKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcariKeyTyped
    kon.setKoneksi();
    BacaTabelPotonganCari();
    }//GEN-LAST:event_tcariKeyTyped

    private void tbpotonganKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbpotonganKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_BACK_SPACE){
        HapusData();
    }
    }//GEN-LAST:event_tbpotonganKeyPressed

    private void tbpotonganMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbpotonganMouseClicked
    SetTabel();
    bttambah.setEnabled(true);
    }//GEN-LAST:event_tbpotonganMouseClicked

    private void tnamaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnamaKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        ttelat.requestFocus();
    }
    }//GEN-LAST:event_tnamaKeyPressed

    private void ttelatKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ttelatKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        tabsen.requestFocus();
    }
    }//GEN-LAST:event_ttelatKeyPressed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
    nonaktif();
    BacaTabelPotongan();
    }//GEN-LAST:event_formWindowOpened

    private void btbrowseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btbrowseActionPerformed
    boolean closable = true;
    data_gaji dataGaji=new data_gaji(null, closable);
    dataGaji.potongan = this;
    dataGaji.setVisible(true);
    dataGaji.setResizable(true);
    bersih();
    bttambah.setEnabled(true);
    tkode.setText(KodeJabatan);
    tnama.setText(NamaJabatan);
    }//GEN-LAST:event_btbrowseActionPerformed

    private void tabsenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tabsenKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        tpph.requestFocus();
    }
    }//GEN-LAST:event_tabsenKeyPressed

    private void tpphKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tpphKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        tbpjs.requestFocus();
    }
    }//GEN-LAST:event_tpphKeyPressed

    private void tbpotonganMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbpotonganMouseReleased
    if(evt.isPopupTrigger()){
        JTable source = (JTable)evt.getSource();
        int row = source.rowAtPoint(evt.getPoint());
        int column = source.columnAtPoint(evt.getPoint());
        if(! source.isRowSelected(row))
            source.changeSelection(row, column, false, false);
        jpop.show(evt.getComponent(), evt.getX(), evt.getY());
    }
    }//GEN-LAST:event_tbpotonganMouseReleased

    private void mieditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mieditActionPerformed
    aktif();
    bersih();
    SetTabel();
    ttelat.requestFocus();
    tkode.setEnabled(false);
    tnama.setEnabled(false);
    btbrowse.setEnabled(false);
    bttambah.setEnabled(true);
    bttambah.setText("UPDATE");
    btkeluar.setText("BATAL");
    }//GEN-LAST:event_mieditActionPerformed

    private void mihapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mihapusActionPerformed
    HapusData();
    }//GEN-LAST:event_mihapusActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(master_potongan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(master_potongan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(master_potongan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(master_potongan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new master_potongan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btbrowse;
    private javax.swing.JButton btkeluar;
    private javax.swing.JButton bttambah;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu jpop;
    private javax.swing.JMenuItem miedit;
    private javax.swing.JMenuItem mihapus;
    private javax.swing.JTextField tabsen;
    private javax.swing.JTextField tbpjs;
    private javax.swing.JTable tbpotongan;
    private javax.swing.JTextField tcari;
    private javax.swing.JTextField tkode;
    private javax.swing.JTextField tnama;
    private javax.swing.JTextField tpph;
    private javax.swing.JTextField ttelat;
    // End of variables declaration//GEN-END:variables
}
