/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplikasi_penggajian;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.KeyEvent;
import java.util.HashMap;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.view.JasperViewer;
import net.sf.jasperreports.engine.JasperPrint;
/**
 *
 * @author Baihirul Fuat
 */
public class form_transaksi extends javax.swing.JFrame {
koneksi kon=new koneksi();
private Object [][] datatransaksi=null;
private String[] label={"Nomor Slip","Tanggal Slip","Periode","Kode User","NIP",
    "Nama Karyawan","Jabatan","Status Pernikahan","Total Masuk","Total Absen",
    "Total Waktu Telat","Total Izin","Total Waktu Lembur","Gaji Pokok",
    "Tunjangan Jabatan","Tunjangan Keluarga","Uang Makan","Uang Lembur",
    "Potongan Telat","Potongan Absen","Potongan PPh 21","Potongan BPJS",
    "Potongan Lain-lain","Keterangan","Total Pendapatan","Total Potongan","Jumlah Gaji"};
String UangMakan,UangLembur,PotonganTelat,PotonganAbsen;
    /**
     * Creates new form transaksi
     */
    public form_transaksi() {
        initComponents();
        kon.setKoneksi();
        setTanggal();
        BacaTabelTransaksi();
        awal();
    }
    
    public Date date=new Date();
    public SimpleDateFormat noformat=new SimpleDateFormat("yyMM");
    public String KodeUser;
    public String Periode;
    public String NIP;
    public String NamaKaryawan;
    public String Jabatan;
    public String TotalMasuk;
    public String TotalAbsen;
    public String TotalTelat;
    public String TotalIzin;
    public String TotalLembur;
        public String getKodeUser(){
            return KodeUser;
        }
        public String getPeriode(){
            return Periode;
        }
        public String getNIP(){
            return NIP;
        }
        public String getNamaKaryawan(){
            return NamaKaryawan;
        }
        public String getJabatan(){
            return Jabatan;
        }
        public String getTotalMasuk(){
            return TotalMasuk;
        }
        public String getTotalAbsen(){
            return TotalAbsen;
        }
        public String getTotalTelat(){
            return TotalTelat;
        }
        public String getTotalIzin(){
            return TotalIzin;
        }
        public String getTotalLembur(){
            return TotalLembur;
        }
        
    private void awal(){
        nonaktif();
    }
        
    private void bersih(){
        tnoslip.setText("");
        tperiode.setText("");
        tnip.setText("");
        tnama.setText("");
        tjabatan.setText("");
        tstatus.setText("");
        tmasuk.setText("");
        tabsen.setText("");
        ttelat.setText("");
        tizin.setText("");
        tlembur.setText("");
        tgaji.setText("");
        ttjjabatan.setText("");
        ttjkeluarga.setText("");
        tuangmakan.setText("");
        tuanglembur.setText("");
        tpottelat.setText("");
        tpotabsen.setText("");
        tpotpph.setText("");
        tpotbpjs.setText("");
        tpotlain.setText("");
        tketerangan.setText("");
        ttotalpendapatan.setText("");
        ttotalpotongan.setText("");
        tjumlahgaji.setText("");
    }    
    
    private void nonaktif(){
        tnoslip.setEditable(false);
        ttgl.setEditable(false);
        tperiode.setEditable(false);
        tkode.setEditable(false);
        tnip.setEditable(false);
        tnama.setEditable(false);
        tjabatan.setEditable(false);
        tstatus.setEditable(false);
        tmasuk.setEditable(false);
        tabsen.setEditable(false);
        ttelat.setEditable(false);
        tizin.setEditable(false);
        tlembur.setEditable(false);
        tgaji.setEditable(false);
        ttjjabatan.setEditable(false);
        ttjkeluarga.setEditable(false);
        tuangmakan.setEditable(false);
        tuanglembur.setEditable(false);
        tpottelat.setEditable(false);
        tpotabsen.setEditable(false);
        tpotpph.setEditable(false);
        tpotbpjs.setEditable(false);
        tpotlain.setEditable(false);
        tketerangan.setEditable(false);
        btbrowse.setEnabled(false);
    }
    
    private void aktif(){
        btbrowse.setEnabled(true);
    }
    
    void setTanggal(){
        java.util.Date skrg = new java.util.Date();
        java.text.SimpleDateFormat kal = new java.text.SimpleDateFormat("yyyy-MM-dd");
        ttgl.setText(kal.format(skrg));
    }
    
    public String NomorTransaksi(){
        String notrans=null;
        notrans="SL-"+NIP+noformat.format(date)+Periode;
        return notrans;
    }
    
    private void BacaTabelTransaksi(){
        try{
            String sql="select * from transaksi order by no_slip";
            kon.rs=kon.st.executeQuery(sql);
            ResultSetMetaData m=kon.rs.getMetaData();
            int kolom=m.getColumnCount();
            int baris=0;
            while(kon.rs.next()){
                baris=kon.rs.getRow();
            }
            datatransaksi=new Object[baris][kolom];
            int x=0;
            kon.rs.beforeFirst();
            while(kon.rs.next()){
                datatransaksi[x][0]=kon.rs.getString("no_slip");
                datatransaksi[x][1]=kon.rs.getString("tgl_slip");
                datatransaksi[x][2]=kon.rs.getString("periode");
                datatransaksi[x][3]=kon.rs.getString("kd_user");
                datatransaksi[x][4]=kon.rs.getString("nip");
                datatransaksi[x][5]=kon.rs.getString("nama_karyawan");
                datatransaksi[x][6]=kon.rs.getString("jabatan");
                datatransaksi[x][7]=kon.rs.getString("status_pernikahan");
                datatransaksi[x][8]=kon.rs.getString("total_masuk");
                datatransaksi[x][9]=kon.rs.getString("total_absen");
                datatransaksi[x][10]=kon.rs.getString("total_telat");
                datatransaksi[x][11]=kon.rs.getString("total_izin");
                datatransaksi[x][12]=kon.rs.getString("total_lembur");
                datatransaksi[x][13]=kon.rs.getString("gaji_pokok");
                datatransaksi[x][14]=kon.rs.getString("tj_jabatan");
                datatransaksi[x][15]=kon.rs.getString("tj_keluarga");
                datatransaksi[x][16]=kon.rs.getString("uang_makan");
                datatransaksi[x][17]=kon.rs.getString("uang_lembur");
                datatransaksi[x][18]=kon.rs.getString("pot_telat");
                datatransaksi[x][19]=kon.rs.getString("pot_absen");
                datatransaksi[x][20]=kon.rs.getString("pot_pph21");
                datatransaksi[x][21]=kon.rs.getString("pot_bpjs");
                datatransaksi[x][22]=kon.rs.getString("pot_lain");
                datatransaksi[x][23]=kon.rs.getString("keterangan");
                datatransaksi[x][24]=kon.rs.getString("total_pendapatan");
                datatransaksi[x][25]=kon.rs.getString("total_potongan");
                datatransaksi[x][26]=kon.rs.getString("jumlah_gaji");
                x++;
            }
            tbtransaksi.setModel(new DefaultTableModel(datatransaksi,label));
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void BacaTabelTransaksiCari(){
        try{
            String sql="select * from transaksi where nama_karyawan like '%" +tcari.getText()+ "%'";
            kon.rs=kon.st.executeQuery(sql);
            ResultSetMetaData m=kon.rs.getMetaData();
            int kolom=m.getColumnCount();
            int baris=0;
            while(kon.rs.next()){
                baris=kon.rs.getRow();
            }
            datatransaksi=new Object[baris][kolom];
            int x=0;
            kon.rs.beforeFirst();
            while(kon.rs.next()){
                datatransaksi[x][0]=kon.rs.getString("no_slip");
                datatransaksi[x][1]=kon.rs.getString("tgl_slip");
                datatransaksi[x][2]=kon.rs.getString("periode");
                datatransaksi[x][3]=kon.rs.getString("kd_user");
                datatransaksi[x][4]=kon.rs.getString("nip");
                datatransaksi[x][5]=kon.rs.getString("nama_karyawan");
                datatransaksi[x][6]=kon.rs.getString("jabatan");
                datatransaksi[x][7]=kon.rs.getString("status_pernikahan");
                datatransaksi[x][8]=kon.rs.getString("total_masuk");
                datatransaksi[x][9]=kon.rs.getString("total_absen");
                datatransaksi[x][10]=kon.rs.getString("total_telat");
                datatransaksi[x][11]=kon.rs.getString("total_izin");
                datatransaksi[x][12]=kon.rs.getString("total_lembur");
                datatransaksi[x][13]=kon.rs.getString("gaji_pokok");
                datatransaksi[x][14]=kon.rs.getString("tj_jabatan");
                datatransaksi[x][15]=kon.rs.getString("tj_keluarga");
                datatransaksi[x][16]=kon.rs.getString("uang_makan");
                datatransaksi[x][17]=kon.rs.getString("uang_lembur");
                datatransaksi[x][18]=kon.rs.getString("pot_telat");
                datatransaksi[x][19]=kon.rs.getString("pot_absen");
                datatransaksi[x][20]=kon.rs.getString("pot_pph21");
                datatransaksi[x][21]=kon.rs.getString("pot_bpjs");
                datatransaksi[x][22]=kon.rs.getString("pot_lain");
                datatransaksi[x][23]=kon.rs.getString("keterangan");
                datatransaksi[x][24]=kon.rs.getString("total_pendapatan");
                datatransaksi[x][25]=kon.rs.getString("total_potongan");
                datatransaksi[x][26]=kon.rs.getString("jumlah_gaji");
                x++;
            }
            tbtransaksi.setModel(new DefaultTableModel(datatransaksi,label));
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void SimpanData(){
        if(tnoslip.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Nomor Slip Tidak Boleh Kosong");
            }
            else if(ttgl.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Tanggal Tidak Boleh Kosong");
            }
            else if(tperiode.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Periode Tidak Boleh Kosong");
            }
            else if(tkode.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Kode User Tidak Boleh Kosong");
            }
            else if(tnip.getText().equals("")){
                JOptionPane.showMessageDialog(null,"NIP Tidak Boleh Kosong");
            }
            else if(tnama.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Nama Karyawan Tidak Boleh Kosong");
            }
            else if(tjabatan.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Jabatan Tidak Boleh Kosong");
            }
            else if(tstatus.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Status Pernikahan Tidak Boleh Kosong");
            }
            else if(tmasuk.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Total Masuk Tidak Boleh Kosong");
            }
            else if(tabsen.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Total Absen Tidak Boleh Kosong");
            }
            else if(ttelat.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Total Telat Tidak Boleh Kosong");
            }
            else if(tizin.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Total Izin Tidak Boleh Kosong");
            }
            else if(tlembur.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Total Lembur Tidak Boleh Kosong");
            }
            else if(tgaji.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Gaji Pokok Tidak Boleh Kosong");
            }
            else if(ttjjabatan.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Tunjangan Jabatan Tidak Boleh Kosong");
            }
            else if(ttjkeluarga.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Tunjangan Keluarga Tidak Boleh Kosong");
            }
            else if(tuangmakan.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Uang Makan Tidak Boleh Kosong");
            }
            else if(tuanglembur.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Uang Lembur Tidak Boleh Kosong");
            }
            else if(tpottelat.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Potongan Telat Tidak Boleh Kosong");
            }
            else if(tpotabsen.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Potongan Absen Tidak Boleh Kosong");
            }
            else if(tpotpph.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Potongan PPh 21 Tidak Boleh Kosong");
            }
            else if(tpotbpjs.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Potongan BPJS Tidak Boleh Kosong");
            }
            else if(ttotalpendapatan.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Total Pendapatan Tidak Boleh Kosong");
            }
            else if(ttotalpotongan.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Total Potongan Tidak Boleh Kosong");
            }
            else if(tjumlahgaji.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Jumlah Gaji Tidak Boleh Kosong");
            }
            else{
                try{
                    String sql="insert into transaksi values('"+tnoslip.getText()+"',"
                            + "'"+ttgl.getText()+"','"+tperiode.getText()+"',"
                            + "'"+tkode.getText()+"','"+tnip.getText()+"',"
                            + "'"+tnama.getText()+"','"+tjabatan.getText()+"',"
                            + "'"+tstatus.getText()+"','"+tmasuk.getText()+"',"
                            + "'"+tabsen.getText()+"','"+ttelat.getText()+"',"
                            + "'"+tizin.getText()+"','"+tlembur.getText()+"',"
                            + "'"+tgaji.getText()+"','"+ttjjabatan.getText()+"',"
                            + "'"+ttjkeluarga.getText()+"','"+tuangmakan.getText()+"',"
                            + "'"+tuanglembur.getText()+"','"+tpottelat.getText()+"',"
                            + "'"+tpotabsen.getText()+"','"+tpotpph.getText()+"',"
                            + "'"+tpotbpjs.getText()+"','"+tpotlain.getText()+"',"
                            + "'"+tketerangan.getText()+"','"+ttotalpendapatan.getText()+"',"
                            + "'"+ttotalpotongan.getText()+"','"+tjumlahgaji.getText()+"')";
                    kon.st.executeUpdate(sql);
                    JOptionPane.showMessageDialog(null,"Data berhasil disimpan");
                    bttambah.setText("TAMBAH");
                    btkeluar.setText("KELUAR");
                    bersih();
                    nonaktif();
                    BacaTabelTransaksi();
                }
                catch(SQLException e){
                    JOptionPane.showMessageDialog(null, e);
                }
            }
    }
    
    private void HapusData(){
        int row=tbtransaksi.getSelectedRow();
        if(JOptionPane.showConfirmDialog(this,"Yakin ingin menghapus data?",
                "Konfirmasi",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
            try{
                String sql="delete from transaksi where no_slip='"+(String)tbtransaksi.getValueAt(row, 0)+"'";
                kon.st.executeUpdate(sql);
                JOptionPane.showMessageDialog(null,"Data berhasil dihapus");
                bersih();
                BacaTabelTransaksi();
            }
            catch(SQLException e){
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }
    
    private void TampilGaji(){
        try{
            String sql="select * from gaji where nama_jabatan='"+tjabatan.getText()+"'";
            kon.rs=kon.st.executeQuery(sql);
            while(kon.rs.next()){
                tgaji.setText(kon.rs.getString("gaji_pokok"));
                ttjjabatan.setText(kon.rs.getString("tj_jabatan"));
                UangMakan=(kon.rs.getString("uang_makan"));
                UangLembur=(kon.rs.getString("lembur"));
            }
        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void TampilPotongan(){
        try{
            String sql="select * from potongan where nama_jabatan='"+tjabatan.getText()+"'";
            kon.rs=kon.st.executeQuery(sql);
            while(kon.rs.next()){
                tpotpph.setText(kon.rs.getString("pot_pph21"));
                tpotbpjs.setText(kon.rs.getString("pot_bpjs"));
                PotonganTelat=(kon.rs.getString("pot_telat"));
                PotonganAbsen=(kon.rs.getString("pot_absen"));
            }
        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void TampilStatus(){
        try{
            String sql="select * from karyawan where nama_karyawan='"+tnama.getText()+"'";
            kon.rs=kon.st.executeQuery(sql);
            while(kon.rs.next()){
                tstatus.setText(kon.rs.getString("status_pernikahan"));
            }
        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    private void TampilTjKeluarga(){
        if(tstatus.getText().equals("Menikah")){
            try{
            String sql="select * from gaji where nama_jabatan='"+tjabatan.getText()+"'";
            kon.rs=kon.st.executeQuery(sql);
            while(kon.rs.next()){
                ttjkeluarga.setText(kon.rs.getString("tj_keluarga"));
            }
            } catch (SQLException e){
            JOptionPane.showMessageDialog(null, e);
            }
        }
        else{
            ttjkeluarga.setText("0");
        }
        
    }
    
    private void DataGaji(){
        int totalmasuk,makan,totallembur,lembur,uangmakan,uanglembur;
        totalmasuk=Integer.parseInt(tmasuk.getText());
        makan=Integer.parseInt(UangMakan);
        totallembur=Integer.parseInt(tlembur.getText());
        lembur=Integer.parseInt(UangLembur);
        uangmakan=totalmasuk*makan;
        uanglembur=totallembur*lembur;
        tuangmakan.setText(Integer.toString(uangmakan));
        tuanglembur.setText(Integer.toString(uanglembur));
    }
    
    private void DataPotongan(){
        int telat,totaltelat,pottelat,absen,totalabsen,potabsen;
        totaltelat=Integer.parseInt(ttelat.getText());
        pottelat=Integer.parseInt(PotonganTelat);
        totalabsen=Integer.parseInt(tabsen.getText());
        potabsen=Integer.parseInt(PotonganAbsen);
        telat=totaltelat*pottelat;
        absen=totalabsen*potabsen;
        tpottelat.setText(Integer.toString(telat));
        tpotabsen.setText(Integer.toString(absen));
        
    }
    
    private void TotalPendapatan(){
        int pendapatan,gajipokok,tjjabatan,tjkeluarga,uangmakan,uanglembur;
        gajipokok=Integer.parseInt(tgaji.getText());
        tjjabatan=Integer.parseInt(ttjjabatan.getText());
        tjkeluarga=Integer.parseInt(ttjkeluarga.getText());
        uangmakan=Integer.parseInt(tuangmakan.getText());
        uanglembur=Integer.parseInt(tuanglembur.getText());
        pendapatan=gajipokok+tjjabatan+tjkeluarga+uangmakan+uanglembur;
        ttotalpendapatan.setText(Integer.toString(pendapatan));
    }
    
    private void TotalPotongan(){
        int potongan,pottelat,potabsen,potpph21,potbpjs,potlain;
        pottelat=Integer.parseInt(tpottelat.getText());
        potabsen=Integer.parseInt(tpotabsen.getText());
        potpph21=Integer.parseInt(tpotpph.getText());
        potbpjs=Integer.parseInt(tpotbpjs.getText());
        potlain=Integer.parseInt(tpotlain.getText());
        potongan=pottelat+potabsen+potpph21+potbpjs+potlain;
        ttotalpotongan.setText(Integer.toString(potongan));
    }
    
    private void JumlahGaji(){
        int pendapatan,potongan,jumlahgaji;
        pendapatan=Integer.parseInt(ttotalpendapatan.getText());
        potongan=Integer.parseInt(ttotalpotongan.getText());
        jumlahgaji=pendapatan-potongan;
        tjumlahgaji.setText(Integer.toString(jumlahgaji));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpop = new javax.swing.JPopupMenu();
        mihapus = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        tnoslip = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        ttgl = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        tperiode = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        tkode = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        tnama = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        tnip = new javax.swing.JTextField();
        btbrowse = new javax.swing.JButton();
        tjabatan = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        tstatus = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        ttelat = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        tizin = new javax.swing.JTextField();
        tlembur = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        tabsen = new javax.swing.JTextField();
        tmasuk = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        ttjkeluarga = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        tuangmakan = new javax.swing.JTextField();
        tgaji = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        ttjjabatan = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        tuanglembur = new javax.swing.JTextField();
        jPanel9 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        tpotabsen = new javax.swing.JTextField();
        tpottelat = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        tpotpph = new javax.swing.JTextField();
        tpotbpjs = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        tpotlain = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        tketerangan = new javax.swing.JTextField();
        jPanel11 = new javax.swing.JPanel();
        bttambah = new javax.swing.JButton();
        btkeluar = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        jLabel28 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        ttotalpendapatan = new javax.swing.JTextField();
        tjumlahgaji = new javax.swing.JTextField();
        ttotalpotongan = new javax.swing.JTextField();
        jPanel13 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        tcari = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbtransaksi = new javax.swing.JTable();

        mihapus.setText("Hapus");
        mihapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mihapusActionPerformed(evt);
            }
        });
        jpop.add(mihapus);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Transaksi Penggajian");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(43, 203, 186));

        jPanel2.setBackground(new java.awt.Color(43, 203, 186));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jLabel1.setText("No. Slip");

        jLabel2.setText("Tgl. Slip");

        jLabel3.setText("Periode");

        jLabel24.setText("Kode User");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(tnoslip, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(108, 108, 108)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(ttgl, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(tperiode, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(135, 135, 135)
                .addComponent(jLabel24)
                .addGap(18, 18, 18)
                .addComponent(tkode, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(tnoslip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(ttgl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(tperiode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel24)
                    .addComponent(tkode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel13.setText("INPUT DATA TRANSAKSI");

        jPanel4.setBackground(new java.awt.Color(43, 203, 186));
        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jPanel3.setBackground(new java.awt.Color(43, 203, 186));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Data Karyawan"));

        jLabel5.setText("Nama Karyawan");

        jLabel6.setText("Jabatan");

        jLabel4.setText("NIP");

        btbrowse.setText("...");
        btbrowse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btbrowseActionPerformed(evt);
            }
        });

        jLabel33.setText("Status Pernikahan");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jLabel4)
                    .addComponent(jLabel6)
                    .addComponent(jLabel33))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(tnip, javax.swing.GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btbrowse))
                    .addComponent(tstatus)
                    .addComponent(tjabatan)
                    .addComponent(tnama, javax.swing.GroupLayout.Alignment.TRAILING)))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(tnip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btbrowse))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(tnama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(tjabatan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel33)
                    .addComponent(tstatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel5.setBackground(new java.awt.Color(43, 203, 186));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jPanel6.setBackground(new java.awt.Color(43, 203, 186));
        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Data Absensi"));

        jLabel16.setText("Total Absen");

        jLabel18.setText("Total Masuk");

        jLabel15.setText("Total Waktu Telat");

        jLabel19.setText("Total Izin");

        jLabel20.setText("Total Waktu Lembur");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15)
                    .addComponent(jLabel19)
                    .addComponent(jLabel20)
                    .addComponent(jLabel16)
                    .addComponent(jLabel18))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tizin, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 121, Short.MAX_VALUE)
                    .addComponent(ttelat, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(tlembur, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(tabsen)
                    .addComponent(tmasuk))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(tmasuk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(tabsen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(ttelat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(tizin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tlembur, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel7.setBackground(new java.awt.Color(43, 203, 186));
        jPanel7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jPanel8.setBackground(new java.awt.Color(43, 203, 186));
        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder("Data Gaji"));

        jLabel9.setText("Tunjangan Keluarga");

        jLabel17.setText("Uang Makan");

        jLabel7.setText("Gaji Pokok");

        jLabel8.setText("Tunjangan Jabatan");

        jLabel21.setText("Uang Lembur");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel17)
                    .addComponent(jLabel21)
                    .addComponent(jLabel9)
                    .addComponent(jLabel8)
                    .addComponent(jLabel7))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tuangmakan, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                    .addComponent(tgaji, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(ttjjabatan, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(ttjkeluarga)
                    .addComponent(tuanglembur))
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(tgaji, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(ttjjabatan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(ttjkeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(tuangmakan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(tuanglembur, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addGap(1, 1, 1)
                .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel9.setBackground(new java.awt.Color(43, 203, 186));
        jPanel9.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jPanel10.setBackground(new java.awt.Color(43, 203, 186));
        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder("Data Potongan"));

        jLabel10.setText("Potongan Telat");

        jLabel11.setText("Potongan Absen");

        jLabel22.setText("Potongan PPh 21");

        jLabel23.setText("Potongan BPJS");

        jLabel27.setText("Potongan Lain-lain");

        tpotlain.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tpotlainKeyPressed(evt);
            }
        });

        jLabel30.setText("Keterangan");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel27)
                    .addComponent(jLabel30)
                    .addComponent(jLabel11)
                    .addComponent(jLabel10)
                    .addComponent(jLabel22)
                    .addComponent(jLabel23))
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(tpotlain, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                    .addComponent(tpotbpjs, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tpotpph, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tpotabsen, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tpottelat, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tketerangan))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(tpottelat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(tpotabsen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(tpotpph, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(tpotbpjs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(tpotlain, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel30)
                    .addComponent(tketerangan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel11.setBackground(new java.awt.Color(43, 203, 186));
        jPanel11.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        bttambah.setText("TAMBAH");
        bttambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttambahActionPerformed(evt);
            }
        });

        btkeluar.setText("KELUAR");
        btkeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btkeluarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(166, 166, 166)
                .addComponent(bttambah)
                .addGap(81, 81, 81)
                .addComponent(btkeluar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bttambah)
                    .addComponent(btkeluar))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        jPanel12.setBackground(new java.awt.Color(43, 203, 186));
        jPanel12.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jLabel28.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel28.setText("Total Potongan");

        jLabel31.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel31.setText("Jumlah Gaji");

        jLabel25.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel25.setText("Total Pendapatan");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel25)
                    .addComponent(jLabel31))
                .addGap(18, 18, 18)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tjumlahgaji, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
                    .addComponent(ttotalpendapatan))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel28)
                .addGap(18, 18, 18)
                .addComponent(ttotalpotongan, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(ttotalpendapatan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel25)
                    .addComponent(ttotalpotongan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tjumlahgaji, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel31))
                .addContainerGap())
        );

        jPanel13.setBackground(new java.awt.Color(43, 203, 186));
        jPanel13.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jPanel14.setBackground(new java.awt.Color(43, 203, 186));
        jPanel14.setBorder(javax.swing.BorderFactory.createTitledBorder("TABEL DATA TRANSAKSI"));

        jLabel14.setText("Cari Nama Karyawan");

        tcari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tcariKeyTyped(evt);
            }
        });

        tbtransaksi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbtransaksi.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tbtransaksi.setMinimumSize(new java.awt.Dimension(80, 64));
        tbtransaksi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                tbtransaksiMouseReleased(evt);
            }
        });
        tbtransaksi.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tbtransaksiKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(tbtransaksi);

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addGap(18, 18, 18)
                        .addComponent(tcari, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(tcari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 122, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, 81, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btbrowseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btbrowseActionPerformed
        boolean closable = true;
        data_absensi dataAbsensi=new data_absensi(null, closable);
        dataAbsensi.transaksi = this;
        dataAbsensi.setVisible(true);
        dataAbsensi.setResizable(true);
        bersih();
        tpotlain.setEditable(true);
        tketerangan.setEditable(true);
        tpotlain.requestFocus();
        tperiode.setText(Periode);
        tnip.setText(NIP);
        tnama.setText(NamaKaryawan);
        tjabatan.setText(Jabatan);
        tmasuk.setText(TotalMasuk);
        tabsen.setText(TotalAbsen);
        ttelat.setText(TotalTelat);
        tizin.setText(TotalIzin);
        tlembur.setText(TotalLembur);
        TampilGaji();
        TampilPotongan();
        TampilStatus();
        TampilTjKeluarga();
        tnoslip.setText(NomorTransaksi());
        DataGaji();
        DataPotongan();
        TotalPendapatan();
    }//GEN-LAST:event_btbrowseActionPerformed

    private void tpotlainKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tpotlainKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
            if(tpotlain.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Potongan Lain-lain Tidak Boleh Kosong");
            }
            else if(!tpotlain.getText().equals("")){
                TotalPotongan();
                JumlahGaji();
                tketerangan.requestFocus();
            }
        }
    }//GEN-LAST:event_tpotlainKeyPressed

    private void bttambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttambahActionPerformed
        if(bttambah.getText().equals("TAMBAH")){
            bttambah.setText("SIMPAN");
            btkeluar.setText("BATAL");
            bersih();
            aktif();
            tnip.requestFocus();
        }
        else if(bttambah.getText().equals("SIMPAN")){
            if(tpotlain.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Potongan Lain-lain Tidak Boleh Kosong");
            }
            else if(!(tpotlain.getText().equals("0"))){
                if(tketerangan.getText().equals("")){
                    JOptionPane.showMessageDialog(null,"Keterangan Tidak Boleh Kosong");
                }
                else if(!(tketerangan.getText().equals(""))){
                    SimpanData();
                    BacaTabelTransaksi();
                }
            }
            else if(tpotlain.getText().length()>=0){
                SimpanData();
                BacaTabelTransaksi();
            }
        }
    }//GEN-LAST:event_bttambahActionPerformed

    private void btkeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btkeluarActionPerformed
        if(btkeluar.getText().equals("KELUAR")){
            dispose();
        }
        else if(btkeluar.getText().equals("BATAL")){
            bersih();
            nonaktif();
            btkeluar.setText("KELUAR");
            bttambah.setText("TAMBAH");
        }
    }//GEN-LAST:event_btkeluarActionPerformed

    private void tcariKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcariKeyTyped
        kon.setKoneksi();
        BacaTabelTransaksiCari();
    }//GEN-LAST:event_tcariKeyTyped

    private void tbtransaksiMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbtransaksiMouseReleased
        if(evt.isPopupTrigger()){
            JTable source = (JTable)evt.getSource();
            int row = source.rowAtPoint(evt.getPoint());
            int column = source.columnAtPoint(evt.getPoint());
            if(! source.isRowSelected(row))
            source.changeSelection(row, column, false, false);
            jpop.show(evt.getComponent(), evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_tbtransaksiMouseReleased

    private void tbtransaksiKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbtransaksiKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_BACK_SPACE){
            HapusData();
        }
    }//GEN-LAST:event_tbtransaksiKeyPressed

    private void mihapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mihapusActionPerformed
        HapusData();
    }//GEN-LAST:event_mihapusActionPerformed

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
    tkode.setText(KodeUser);
    }//GEN-LAST:event_formWindowActivated

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(form_transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(form_transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(form_transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(form_transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new form_transaksi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btbrowse;
    private javax.swing.JButton btkeluar;
    private javax.swing.JButton bttambah;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu jpop;
    private javax.swing.JMenuItem mihapus;
    private javax.swing.JTextField tabsen;
    private javax.swing.JTable tbtransaksi;
    private javax.swing.JTextField tcari;
    private javax.swing.JTextField tgaji;
    private javax.swing.JTextField tizin;
    private javax.swing.JTextField tjabatan;
    private javax.swing.JTextField tjumlahgaji;
    private javax.swing.JTextField tketerangan;
    private javax.swing.JTextField tkode;
    private javax.swing.JTextField tlembur;
    private javax.swing.JTextField tmasuk;
    private javax.swing.JTextField tnama;
    private javax.swing.JTextField tnip;
    private javax.swing.JTextField tnoslip;
    private javax.swing.JTextField tperiode;
    private javax.swing.JTextField tpotabsen;
    private javax.swing.JTextField tpotbpjs;
    private javax.swing.JTextField tpotlain;
    private javax.swing.JTextField tpotpph;
    private javax.swing.JTextField tpottelat;
    private javax.swing.JTextField tstatus;
    private javax.swing.JTextField ttelat;
    private javax.swing.JTextField ttgl;
    private javax.swing.JTextField ttjjabatan;
    private javax.swing.JTextField ttjkeluarga;
    private javax.swing.JTextField ttotalpendapatan;
    private javax.swing.JTextField ttotalpotongan;
    private javax.swing.JTextField tuanglembur;
    private javax.swing.JTextField tuangmakan;
    // End of variables declaration//GEN-END:variables
}
