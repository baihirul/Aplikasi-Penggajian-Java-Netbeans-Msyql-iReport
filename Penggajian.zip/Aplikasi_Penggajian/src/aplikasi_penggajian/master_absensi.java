package aplikasi_penggajian;
import java.awt.event.KeyEvent;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.text.*;
import java.util.Date;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Baihirul Fuat
 */
public class master_absensi extends javax.swing.JFrame {
koneksi kon = new koneksi();
private Object [][] dataabsensi=null;
private String[] label={"Nomor Absensi","NIP","Periode","Nama Karyawan","Jabatan","Total Masuk","Total Absen","Total Telat (menit)","Total Izin","Total Lembur (menit)"};
String periode,Bulan,Tahun;
    /**
     * Creates new form data_absen
     */
    public master_absensi() {
        initComponents();
        kon.setKoneksi();
        BacaTabelAbsensi();
        awal();
        tbulan.setVisible(false);
        ttahun.setVisible(false);
        tjabatan.setEditable(false);
    }
    
    public String NIP;
    public String NamaKaryawan;
    public String Jabatan;
        public String getNIP(){
            return NIP;
        }
        public String getNamaKaryawan(){
            return NamaKaryawan;
        }
        public String getJabatan(){
            return Jabatan;
        }
    
    private void BacaTabelAbsensi(){
        try{
            String sql="select * from absensi order by no_absensi";
            kon.rs=kon.st.executeQuery(sql);
            ResultSetMetaData m=kon.rs.getMetaData();
            int kolom=m.getColumnCount();
            int baris=0;
            while(kon.rs.next()){
                baris=kon.rs.getRow();
            }
            dataabsensi=new Object[baris][kolom];
            int x=0;
            kon.rs.beforeFirst();
            while(kon.rs.next()){
                dataabsensi[x][0]=kon.rs.getString("no_absensi");
                dataabsensi[x][1]=kon.rs.getString("nip");
                dataabsensi[x][2]=kon.rs.getString("periode");
                dataabsensi[x][3]=kon.rs.getString("nama_karyawan");
                dataabsensi[x][4]=kon.rs.getString("jabatan");
                dataabsensi[x][5]=kon.rs.getString("total_masuk");
                dataabsensi[x][6]=kon.rs.getString("total_absen");
                dataabsensi[x][7]=kon.rs.getString("total_telat");
                dataabsensi[x][8]=kon.rs.getString("total_izin");
                dataabsensi[x][9]=kon.rs.getString("total_lembur");
                x++;
            }
            tbabsensi.setModel(new DefaultTableModel(dataabsensi,label));
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void BacaTabelAbsensiCari(){
        try{
            String sql="select * from absensi where nama_karyawan like '%" +tcari.getText()+ "%'";
            kon.rs=kon.st.executeQuery(sql);
            ResultSetMetaData m=kon.rs.getMetaData();
            int kolom=m.getColumnCount();
            int baris=0;
            while(kon.rs.next()){
                baris=kon.rs.getRow();
            }
            dataabsensi=new Object[baris][kolom];
            int x=0;
            kon.rs.beforeFirst();
            while(kon.rs.next()){
                dataabsensi[x][0]=kon.rs.getString("no_absensi");
                dataabsensi[x][1]=kon.rs.getString("nip");
                dataabsensi[x][2]=kon.rs.getString("periode");
                dataabsensi[x][3]=kon.rs.getString("nama_karyawan");
                dataabsensi[x][4]=kon.rs.getString("jabatan");
                dataabsensi[x][5]=kon.rs.getString("total_masuk");
                dataabsensi[x][6]=kon.rs.getString("total_absen");
                dataabsensi[x][7]=kon.rs.getString("total_telat");
                dataabsensi[x][8]=kon.rs.getString("total_izin");
                dataabsensi[x][9]=kon.rs.getString("total_lembur");
                x++;
            }
            tbabsensi.setModel(new DefaultTableModel(dataabsensi,label));
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public String NomorAbsensi(){
        String noabsensi=tnip.getText()+("-")+periode;
        return noabsensi;
    }
    
    private void FormatPeriode(){
        int year = ctahun.getYear()-1900;
        int month = cbulan.getMonth();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
        java.util.Date dt = new java.util.Date(year, month,1);
        periode = sdf.format(dt);
    }
    
    private void SetPeriode(){
        Bulan=(tbulan.getText().toString().substring(4,6));
        Tahun=(ttahun.getText().toString().substring(0,4));
        int bulan = Integer.parseInt(Bulan)-(1);
        int tahun = Integer.parseInt(Tahun);
        cbulan.setMonth(bulan);
        ctahun.setYear(tahun);
    }
    
    private void SetTabel(){
        int row=tbabsensi.getSelectedRow();
        tnoabsensi.setText((String)tbabsensi.getValueAt(row, 0));
        tnip.setText((String)tbabsensi.getValueAt(row, 1));
        tbulan.setText((String)tbabsensi.getValueAt(row, 2));
        ttahun.setText((String)tbabsensi.getValueAt(row, 2));
        tnama.setText((String)tbabsensi.getValueAt(row, 3));
        tjabatan.setText((String)tbabsensi.getValueAt(row, 4));
        tmasuk.setText((String)tbabsensi.getValueAt(row, 5));
        tabsen.setText((String)tbabsensi.getValueAt(row, 6));
        ttelat.setText((String)tbabsensi.getValueAt(row, 7));
        tizin.setText((String)tbabsensi.getValueAt(row, 8));
        tlembur.setText((String)tbabsensi.getValueAt(row, 9));
    }
    
    private void awal(){
        tnoabsensi.setEnabled(false);
        tnip.setEnabled(false);
    }
    
    private void bersih(){
        tnoabsensi.setText("");
        tnip.setText("");
        //cbulan.setMonth(00);
        ctahun.setYear(1900);
        tnama.setText("");
        tjabatan.setText("");
        tmasuk.setText("");
        tabsen.setText("");
        ttelat.setText("");
        tizin.setText("");
        tlembur.setText("");
    }
    
    private void aktif(){
        cbulan.setEnabled(true);
        ctahun.setEnabled(true);
        tnama.setEnabled(true);
        tjabatan.setEnabled(true);
        tmasuk.setEnabled(true);
        tabsen.setEnabled(true);
        ttelat.setEnabled(true);
        tizin.setEnabled(true);
        tlembur.setEnabled(true);
        btbrowse.setEnabled(true);
    }
    
    private void nonaktif(){
        cbulan.setEnabled(false);
        ctahun.setEnabled(false);
        tnama.setEnabled(false);
        tjabatan.setEnabled(false);
        tmasuk.setEnabled(false);
        tabsen.setEnabled(false);
        ttelat.setEnabled(false);
        tizin.setEnabled(false);
        tlembur.setEnabled(false);
        btbrowse.setEnabled(false);
    }
    
    private void SimpanData(){
        if(tnip.getText().equals("")){
                JOptionPane.showMessageDialog(null,"NIP Tidak Boleh Kosong");
            }
            else if(ctahun.getYear()==1900){
                JOptionPane.showMessageDialog(null,"Pastikan Periode Sudah Benar");
            }
            else if(tnama.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Nama Karyawan Tidak Boleh Kosong");
            }
            else if(tjabatan.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Jabatan Tidak Boleh Kosong");
            }
            else if(tmasuk.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Total Masuk Tidak Boleh Kosong");
            }
            else if(tabsen.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Total Absen Tidak Boleh Kosong");
            }
            else if(ttelat.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Total Telat Tidak Boleh Kosong");
            }
            else if(tizin.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Total Izin Tidak Boleh Kosong");
            }
            else if(tlembur.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Total Lembur Tidak Boleh Kosong");
            }
            else{
                try{
                    String sql="insert into absensi values('"+tnoabsensi.getText()+"','"+tnip.getText()+"','"+periode+"','"+tnama.getText()+"','"+tjabatan.getText()+"','"+tmasuk.getText()+"','"+tabsen.getText()+"','"+ttelat.getText()+"','"+tizin.getText()+"','"+tlembur.getText()+"')";
                    kon.st.executeUpdate(sql);
                    JOptionPane.showMessageDialog(null,"Data berhasil disimpan");
                    bttambah.setText("TAMBAH");
                    btkeluar.setText("KELUAR");
                    bersih();
                    nonaktif();
                    BacaTabelAbsensi();
                }
                catch(SQLException e){
                    JOptionPane.showMessageDialog(null, e);
                }
            }
    }
    
    private void UpdateData(){
        if(tnip.getText().equals("")){
                JOptionPane.showMessageDialog(null,"NIP Tidak Boleh Kosong");
            }
            else if(ctahun.getYear()==1900){
                JOptionPane.showMessageDialog(null,"Pastikan Periode Sudah Benar");
            }
            else if(tnama.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Nama Karyawan Tidak Boleh Kosong");
            }
            else if(tjabatan.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Jabatan Tidak Boleh Kosong");
            }
            else if(tmasuk.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Total Masuk Tidak Boleh Kosong");
            }
            else if(tabsen.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Total Absen Tidak Boleh Kosong");
            }
            else if(ttelat.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Total Telat Tidak Boleh Kosong");
            }
            else if(tizin.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Total Izin Tidak Boleh Kosong");
            }
            else if(tlembur.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Total Lembur Tidak Boleh Kosong");
            }
            else{
                try{
                    String sql="update absensi set no_absensi='"+tnoabsensi.getText()+"',nip='"+tnip.getText()+"',periode='"+periode+"',nama_karyawan='"+tnama.getText()+"',jabatan='"+tjabatan.getText()+"',total_masuk='"+tmasuk.getText()+"',total_absen='"+tabsen.getText()+"',total_telat='"+ttelat.getText()+"',total_izin='"+tizin.getText()+"',total_lembur='"+tlembur.getText()+"' where no_absensi='"+tnoabsensi.getText()+"'";
                    kon.st.executeUpdate(sql);
                    JOptionPane.showMessageDialog(null,"Data berhasil diedit");
                    bttambah.setText("TAMBAH");
                    btkeluar.setText("KELUAR");
                    bersih();
                    nonaktif();
                    BacaTabelAbsensi();
                }
                catch(SQLException e){
                    JOptionPane.showMessageDialog(null, e);
                }
            }
    }
    
    private void HapusData(){
        if(JOptionPane.showConfirmDialog(this,"Yakin ingin menghapus data?","Konfirmasi",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
            try{
                String sql="delete from absensi where no_absensi='"+tnoabsensi.getText()+"'";
                kon.st.executeUpdate(sql);
                JOptionPane.showMessageDialog(null,"Data berhasil dihapus");
                bersih();
                BacaTabelAbsensi();
            }
            catch(SQLException e){
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpop = new javax.swing.JPopupMenu();
        miedit = new javax.swing.JMenuItem();
        mihapus = new javax.swing.JMenuItem();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        tcari = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbabsensi = new javax.swing.JTable();
        tbulan = new javax.swing.JTextField();
        ttahun = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        bttambah = new javax.swing.JButton();
        btkeluar = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        tnip = new javax.swing.JTextField();
        tnama = new javax.swing.JTextField();
        tmasuk = new javax.swing.JTextField();
        tabsen = new javax.swing.JTextField();
        btbrowse = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        tnoabsensi = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        tjabatan = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        cbulan = new com.toedter.calendar.JMonthChooser();
        ctahun = new com.toedter.calendar.JYearChooser();
        ttelat = new javax.swing.JTextField();
        tizin = new javax.swing.JTextField();
        tlembur = new javax.swing.JTextField();

        miedit.setText("Edit");
        miedit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mieditActionPerformed(evt);
            }
        });
        jpop.add(miedit);

        mihapus.setText("Hapus");
        mihapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mihapusActionPerformed(evt);
            }
        });
        jpop.add(mihapus);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Master Absensi");
        setPreferredSize(new java.awt.Dimension(1296, 700));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(43, 203, 186));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("TABEL DATA ABSENSI");

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("INPUT DATA ABSENSI");

        jPanel2.setBackground(new java.awt.Color(43, 203, 186));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jLabel8.setText("Cari Nama Karyawan");

        tcari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tcariKeyTyped(evt);
            }
        });

        tbabsensi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbabsensi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbabsensiMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                tbabsensiMouseReleased(evt);
            }
        });
        tbabsensi.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tbabsensiKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(tbabsensi);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(18, 18, 18)
                        .addComponent(tcari, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(tbulan, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(ttahun, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 866, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(tcari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tbulan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ttahun, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 410, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel3.setBackground(new java.awt.Color(43, 203, 186));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        bttambah.setText("TAMBAH");
        bttambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttambahActionPerformed(evt);
            }
        });

        btkeluar.setText("KELUAR");
        btkeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btkeluarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bttambah)
                .addGap(18, 18, 18)
                .addComponent(btkeluar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bttambah)
                    .addComponent(btkeluar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(43, 203, 186));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jPanel1.setBackground(new java.awt.Color(43, 203, 186));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Data Absensi Karyawan"));

        jLabel2.setText("NIP");

        jLabel3.setText("Nama Karyawan");

        jLabel4.setText("Total Masuk");

        jLabel5.setText("Total Absen");

        jLabel6.setText("Total Telat (menit)");

        jLabel7.setText("Total Izin");

        tnama.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tnamaKeyPressed(evt);
            }
        });

        tmasuk.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tmasukKeyPressed(evt);
            }
        });

        tabsen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tabsenKeyPressed(evt);
            }
        });

        btbrowse.setText("...");
        btbrowse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btbrowseActionPerformed(evt);
            }
        });

        jLabel11.setText("No. Absensi");

        jLabel10.setText("Periode");

        jLabel13.setText("Jabatan");

        tjabatan.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tjabatanKeyPressed(evt);
            }
        });

        jLabel12.setText("Total  Lembur (menit)");

        cbulan.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                cbulanPropertyChange(evt);
            }
        });

        ctahun.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                ctahunPropertyChange(evt);
            }
        });

        ttelat.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                ttelatKeyPressed(evt);
            }
        });

        tizin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tizinKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(jLabel3)
                    .addComponent(jLabel13)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel2)
                    .addComponent(jLabel11)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(jLabel12))
                        .addComponent(jLabel6)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(ttelat)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(tnip, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btbrowse, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(tnama)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(cbulan, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(ctahun, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(tjabatan, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(tmasuk, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(tabsen, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(tnoabsensi)
                    .addComponent(tlembur)
                    .addComponent(tizin))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(tnoabsensi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tnip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btbrowse, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(cbulan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ctahun, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(tnama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13)
                    .addComponent(tjabatan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(tmasuk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(tabsen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(ttelat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(tizin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(tlembur, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(47, 47, 47)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(jLabel9)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(76, 76, 76)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bttambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttambahActionPerformed
    if(bttambah.getText().equals("TAMBAH")){
        bttambah.setEnabled(false);
        bttambah.setText("SIMPAN");
        btkeluar.setText("BATAL");
        bersih();
        aktif();
        btbrowse.requestFocus();
    }
    else if(bttambah.getText().equals("SIMPAN")){
        SimpanData();
        BacaTabelAbsensi();
    }
    else if(bttambah.getText().equals("UPDATE")){
        UpdateData();
        BacaTabelAbsensi();
    }
    }//GEN-LAST:event_bttambahActionPerformed

    private void btkeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btkeluarActionPerformed
    if(btkeluar.getText().equals("KELUAR")){
        dispose();
    }
    else if(btkeluar.getText().equals("BATAL")){
        bersih();
        nonaktif();
        btkeluar.setText("KELUAR");
        bttambah.setText("TAMBAH");
        bttambah.setEnabled(true);
    }
    }//GEN-LAST:event_btkeluarActionPerformed

    private void tcariKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcariKeyTyped
    kon.setKoneksi();
    BacaTabelAbsensiCari();
    }//GEN-LAST:event_tcariKeyTyped

    private void tbabsensiKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbabsensiKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_BACK_SPACE){
        HapusData();
    }
    }//GEN-LAST:event_tbabsensiKeyPressed

    private void tbabsensiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbabsensiMouseClicked
    SetTabel();
    SetPeriode();
    bttambah.setEnabled(true);
    }//GEN-LAST:event_tbabsensiMouseClicked

    private void tnamaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnamaKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        tjabatan.requestFocus();
    }
    }//GEN-LAST:event_tnamaKeyPressed

    private void tmasukKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tmasukKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        tabsen.requestFocus();
    }
    }//GEN-LAST:event_tmasukKeyPressed

    private void tabsenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tabsenKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        ttelat.requestFocus();
    }
    }//GEN-LAST:event_tabsenKeyPressed

    private void ttelatKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ttelatKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        tizin.requestFocus();
    }
    }//GEN-LAST:event_ttelatKeyPressed

    private void btbrowseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btbrowseActionPerformed
    boolean closable = true;
    data_karyawan dataKaryawan=new data_karyawan(null, closable);
    dataKaryawan.absensi = this;
    dataKaryawan.setVisible(true);
    dataKaryawan.setResizable(true);
    bersih();
    bttambah.setEnabled(true);
    cbulan.requestFocus();
    tnip.setText(NIP);
    tnama.setText(NamaKaryawan);
    tjabatan.setText(Jabatan);
    }//GEN-LAST:event_btbrowseActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
    nonaktif();
    tnoabsensi.setEditable(false);
    BacaTabelAbsensi();
    }//GEN-LAST:event_formWindowOpened

    private void tizinKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tizinKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        tlembur.requestFocus();
    }
    }//GEN-LAST:event_tizinKeyPressed

    private void mihapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mihapusActionPerformed
    HapusData();
    }//GEN-LAST:event_mihapusActionPerformed

    private void tbabsensiMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbabsensiMouseReleased
    if(evt.isPopupTrigger()){
        JTable source = (JTable)evt.getSource();
        int row = source.rowAtPoint(evt.getPoint());
        int column = source.columnAtPoint(evt.getPoint());
        if(! source.isRowSelected(row))
            source.changeSelection(row, column, false, false);
        jpop.show(evt.getComponent(), evt.getX(), evt.getY());
    }
    }//GEN-LAST:event_tbabsensiMouseReleased

    private void tjabatanKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tjabatanKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        tmasuk.requestFocus();
    }
    }//GEN-LAST:event_tjabatanKeyPressed

    private void mieditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mieditActionPerformed
    aktif();
    bersih();
    SetTabel();
    cbulan.requestFocus();
    btbrowse.setEnabled(false);
    bttambah.setEnabled(true);
    bttambah.setText("UPDATE");
    btkeluar.setText("BATAL");
    }//GEN-LAST:event_mieditActionPerformed

    private void ctahunPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_ctahunPropertyChange
    FormatPeriode();
    tnoabsensi.setText(NomorAbsensi());
    }//GEN-LAST:event_ctahunPropertyChange

    private void cbulanPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_cbulanPropertyChange
    FormatPeriode();
    tnoabsensi.setText(NomorAbsensi());
    }//GEN-LAST:event_cbulanPropertyChange

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(master_absensi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(master_absensi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(master_absensi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(master_absensi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new master_absensi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btbrowse;
    private javax.swing.JButton btkeluar;
    private javax.swing.JButton bttambah;
    private com.toedter.calendar.JMonthChooser cbulan;
    private com.toedter.calendar.JYearChooser ctahun;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu jpop;
    private javax.swing.JMenuItem miedit;
    private javax.swing.JMenuItem mihapus;
    private javax.swing.JTextField tabsen;
    private javax.swing.JTable tbabsensi;
    private javax.swing.JTextField tbulan;
    private javax.swing.JTextField tcari;
    private javax.swing.JTextField tizin;
    private javax.swing.JTextField tjabatan;
    private javax.swing.JTextField tlembur;
    private javax.swing.JTextField tmasuk;
    private javax.swing.JTextField tnama;
    private javax.swing.JTextField tnip;
    private javax.swing.JTextField tnoabsensi;
    private javax.swing.JTextField ttahun;
    private javax.swing.JTextField ttelat;
    // End of variables declaration//GEN-END:variables
}
