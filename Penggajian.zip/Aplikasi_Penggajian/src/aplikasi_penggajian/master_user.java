/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplikasi_penggajian;
import java.awt.event.KeyEvent;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Baihirul Fuat
 */
public class master_user extends javax.swing.JFrame {
koneksi kon = new koneksi();
private Object [][] datauser=null;
private String[] label={"Kode User","Nama User","Password","Level"};
    /**
     * Creates new form master_user
     */
    public master_user() {
        initComponents();
        kon.setKoneksi();
        BacaTabelUser();
    }
    
    private void BacaTabelUser(){
        try{
            String sql="select * from user order by kd_user";
            kon.rs=kon.st.executeQuery(sql);
            ResultSetMetaData m=kon.rs.getMetaData();
            int kolom=m.getColumnCount();
            int baris=0;
            while(kon.rs.next()){
                baris=kon.rs.getRow();
            }
            datauser=new Object[baris][kolom];
            int x=0;
            kon.rs.beforeFirst();
            while(kon.rs.next()){
                datauser[x][0]=kon.rs.getString("kd_user");
                datauser[x][1]=kon.rs.getString("nama_user");
                datauser[x][2]=kon.rs.getString("password");
                datauser[x][3]=kon.rs.getString("level");
                x++;
            }
            tbuser.setModel(new DefaultTableModel(datauser,label));
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void SetTabel(){
        int row=tbuser.getSelectedRow();
        tkode.setText((String)tbuser.getValueAt(row, 0));
        tnama.setText((String)tbuser.getValueAt(row, 1));
        tpassword.setText((String)tbuser.getValueAt(row, 2));
        tkonfir.setText((String)tbuser.getValueAt(row, 2));
        tlevel.setText((String)tbuser.getValueAt(row, 3));
    }
    
    private void bersih(){
        tkode.setText("");
        tnama.setText("");
        tpassword.setText("");
        tkonfir.setText("");
        tlevel.setText("");
    }
    
    private void aktif(){
        tkode.setEnabled(true);
        tnama.setEnabled(true);
        tpassword.setEnabled(true);
        tkonfir.setEnabled(true);
    }
    
    private void nonaktif(){
        tkode.setEnabled(false);
        tnama.setEnabled(false);
        tpassword.setEnabled(false);
        tkonfir.setEnabled(false);
        tlevel.setEnabled(false);
    }
    
    private void validasi(){
        if(tkode.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Kode User Tidak Boleh Kosong");
            }
            else if(tnama.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Nama User Tidak Boleh Kosong");
            }
            else if(tpassword.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Password Tidak Boleh Kosong");
            }
            else if(tkonfir.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Konfirmasi Password Tidak Boleh Kosong");
            }
            else if(tlevel.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Level Tidak Boleh Kosong");
            }
    }
    
    private void konfirmpassword(){
        try{
            if(tpassword.getText().equals(tkonfir.getText())){
                tlevel.setEnabled(true);
                tlevel.requestFocus();
            }else{
                JOptionPane.showMessageDialog(null, "Password dan konfirmasi"
                        + "password harus sama");
                tkonfir.requestFocus();
                tkonfir.setText("");
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void SimpanData(){
        if(tkode.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Kode User Tidak Boleh Kosong");
        }
        else if(tnama.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Nama User Tidak Boleh Kosong");
        }
        else if(tpassword.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Password Tidak Boleh Kosong");
        }
        else if(tkonfir.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Konfirmasi Password Tidak Boleh Kosong");
        }
        else if(tlevel.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Level Tidak Boleh Kosong");
        }
        else{
            try{
                String sql="insert into user values('"+tkode.getText()+"','"+tnama.getText()+"','"+tpassword.getText()+"','"+tlevel.getText()+"')";
                kon.st.executeUpdate(sql);
                JOptionPane.showMessageDialog(null,"Data berhasil disimpan");
                bttambah.setText("TAMBAH");
                btkeluar.setText("KELUAR");
                bersih();
                nonaktif();
                BacaTabelUser();
            }
            catch(SQLException e){
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }
    
    private void UpdateData(){
        if(tkode.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Kode User Tidak Boleh Kosong");
        }
        else if(tnama.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Nama User Tidak Boleh Kosong");
        }
        else if(tpassword.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Password Tidak Boleh Kosong");
        }
        else if(tkonfir.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Konfirmasi Password Tidak Boleh Kosong");
        }
        else if(tlevel.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Level Tidak Boleh Kosong");
        }
        else{
            try{
                String sql="update user set kd_user='"+tkode.getText()+"',nama_user='"+tnama.getText()+"',password='"+tpassword.getText()+"',level='"+tlevel.getText()+"' where kd_user='"+tkode.getText()+"'";
                kon.st.executeUpdate(sql);
                JOptionPane.showMessageDialog(null,"Data berhasil diedit");
                bttambah.setText("TAMBAH");
                btkeluar.setText("KELUAR");
                bersih();
                nonaktif();
                BacaTabelUser();
            }
            catch(SQLException e){
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }
    
    private void HapusData(){
        if(JOptionPane.showConfirmDialog(this,"Yakin ingin menghapus data?","Konfirmasi",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
            try{
                String sql="delete from user where kd_user='"+tkode.getText()+"'";
                kon.st.executeUpdate(sql);
                JOptionPane.showMessageDialog(null,"Data berhasil dihapus");
                bersih();
                BacaTabelUser();
            }
            catch(SQLException e){
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpop = new javax.swing.JPopupMenu();
        miedit = new javax.swing.JMenuItem();
        mihapus = new javax.swing.JMenuItem();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbuser = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        bttambah = new javax.swing.JButton();
        btkeluar = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        tkode = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        tnama = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        tpassword = new javax.swing.JPasswordField();
        jLabel7 = new javax.swing.JLabel();
        tkonfir = new javax.swing.JPasswordField();
        jLabel8 = new javax.swing.JLabel();
        tlevel = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();

        miedit.setText("Edit");
        miedit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mieditActionPerformed(evt);
            }
        });
        jpop.add(miedit);

        mihapus.setText("Hapus");
        mihapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mihapusActionPerformed(evt);
            }
        });
        jpop.add(mihapus);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Master User");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(43, 203, 186));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("INPUT DATA USER");

        jPanel1.setBackground(new java.awt.Color(43, 203, 186));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        tbuser.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbuser.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbuserMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                tbuserMouseReleased(evt);
            }
        });
        tbuser.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tbuserKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(tbuser);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 935, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 418, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("TABEL DATA USER");

        jPanel3.setBackground(new java.awt.Color(43, 203, 186));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        bttambah.setText("TAMBAH");
        bttambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttambahActionPerformed(evt);
            }
        });

        btkeluar.setText("KELUAR");
        btkeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btkeluarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bttambah)
                .addGap(18, 18, 18)
                .addComponent(btkeluar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bttambah)
                    .addComponent(btkeluar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(43, 203, 186));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jPanel2.setBackground(new java.awt.Color(43, 203, 186));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Data User"));

        jLabel4.setText("Kode User");

        tkode.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tkodeKeyPressed(evt);
            }
        });

        jLabel5.setText("Nama User");

        tnama.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tnamaKeyPressed(evt);
            }
        });

        jLabel6.setText("Password");

        tpassword.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tpasswordKeyPressed(evt);
            }
        });

        jLabel7.setText("Konfirmasi Password");

        tkonfir.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tkonfirKeyPressed(evt);
            }
        });

        jLabel8.setText("Level");

        jLabel9.setText("[1.Direktur 2.Manager]");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(tkode, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tpassword, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tnama, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8))
                        .addGap(29, 29, 29)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(tkonfir, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(tlevel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel9)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(tkode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(tnama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(tpassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(tkonfir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(tlevel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 311, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(62, 62, 62)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(88, 88, 88)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(46, 46, 46)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bttambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttambahActionPerformed
    if(bttambah.getText().equals("TAMBAH")){
        bttambah.setText("SIMPAN");
        btkeluar.setText("BATAL");
        bersih();
        aktif();
        tkode.requestFocus();
    }
    else if(bttambah.getText().equals("SIMPAN")){
        SimpanData();
        BacaTabelUser();     
    }
    else if(bttambah.getText().equals("UPDATE")){
        UpdateData();
        BacaTabelUser();
    }
    }//GEN-LAST:event_bttambahActionPerformed

    private void btkeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btkeluarActionPerformed
    if(btkeluar.getText().equals("KELUAR")){
        dispose();
    }
    else if(btkeluar.getText().equals("BATAL")){
        bersih();
        nonaktif();
        btkeluar.setText("KELUAR");
        bttambah.setText("TAMBAH");
    }
    }//GEN-LAST:event_btkeluarActionPerformed

    private void tkodeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tkodeKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        try{
            String sql="select * from user where kd_user='"+tkode.getText()+"'";
            kon.rs=kon.st.executeQuery(sql);
            if(kon.rs.next()){
                tkode.setEnabled(false);
                tlevel.setEnabled(true);
                tkode.setText(kon.rs.getString("kd_user"));
                tnama.setText(kon.rs.getString("nama_user"));
                tpassword.setText(kon.rs.getString("password"));
                tkonfir.setText(kon.rs.getString("password"));
                tlevel.setText(kon.rs.getString("level"));
                bttambah.setText("UPDATE");
            } else{
                tnama.requestFocus();
            }
        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    }//GEN-LAST:event_tkodeKeyPressed

    private void tbuserKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbuserKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_BACK_SPACE){
        HapusData();
    }
    }//GEN-LAST:event_tbuserKeyPressed

    private void tbuserMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbuserMouseClicked
    SetTabel();
    }//GEN-LAST:event_tbuserMouseClicked

    private void tnamaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnamaKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        tpassword.requestFocus();
    }
    }//GEN-LAST:event_tnamaKeyPressed

    private void tpasswordKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tpasswordKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        tkonfir.requestFocus();
    }
    }//GEN-LAST:event_tpasswordKeyPressed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        nonaktif();
        BacaTabelUser();
    }//GEN-LAST:event_formWindowOpened

    private void tkonfirKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tkonfirKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
            konfirmpassword();
        }
    }//GEN-LAST:event_tkonfirKeyPressed

    private void tbuserMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbuserMouseReleased
    if(evt.isPopupTrigger()){
        JTable source = (JTable)evt.getSource();
        int row = source.rowAtPoint(evt.getPoint());
        int column = source.columnAtPoint(evt.getPoint());
        if(! source.isRowSelected(row))
            source.changeSelection(row, column, false, false);
        jpop.show(evt.getComponent(), evt.getX(), evt.getY());
    }
    }//GEN-LAST:event_tbuserMouseReleased

    private void mieditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mieditActionPerformed
    aktif();
    bersih();
    SetTabel();
    tnama.requestFocus();
    tkode.setEnabled(false);
    tlevel.setEnabled(true);
    bttambah.setEnabled(true);
    bttambah.setText("UPDATE");
    btkeluar.setText("BATAL");
    }//GEN-LAST:event_mieditActionPerformed

    private void mihapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mihapusActionPerformed
    HapusData();
    }//GEN-LAST:event_mihapusActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(master_user.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(master_user.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(master_user.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(master_user.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new master_user().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btkeluar;
    private javax.swing.JButton bttambah;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu jpop;
    private javax.swing.JMenuItem miedit;
    private javax.swing.JMenuItem mihapus;
    private javax.swing.JTable tbuser;
    private javax.swing.JTextField tkode;
    private javax.swing.JPasswordField tkonfir;
    private javax.swing.JTextField tlevel;
    private javax.swing.JTextField tnama;
    private javax.swing.JPasswordField tpassword;
    // End of variables declaration//GEN-END:variables
}
