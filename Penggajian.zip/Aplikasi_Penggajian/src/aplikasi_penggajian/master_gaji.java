/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplikasi_penggajian;
import java.awt.event.KeyEvent;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Baihirul Fuat
 */
public class master_gaji extends javax.swing.JFrame {
koneksi kon = new koneksi();
private Object [][] datagaji=null;
private String[] label={"Kode Jabatan","Nama Jabatan","Gaji Pokok","Tunjangan Jabatan","Tunjangan Keluarga","Uang Makan per Hari","Uang Lembur per Menit"};
    /**
     * Creates new form master_gaji
     */
    public master_gaji() {
        initComponents();
        kon.setKoneksi();
        BacaTabelGaji();
    }
    
    private void BacaTabelGaji(){
        try{
            String sql="select * from gaji order by kd_jabatan";
            kon.rs=kon.st.executeQuery(sql);
            ResultSetMetaData m=kon.rs.getMetaData();
            int kolom=m.getColumnCount();
            int baris=0;
            while(kon.rs.next()){
                baris=kon.rs.getRow();
            }
            datagaji=new Object[baris][kolom];
            int x=0;
            kon.rs.beforeFirst();
            while(kon.rs.next()){
                datagaji[x][0]=kon.rs.getString("kd_jabatan");
                datagaji[x][1]=kon.rs.getString("nama_jabatan");
                datagaji[x][2]=kon.rs.getString("gaji_pokok");
                datagaji[x][3]=kon.rs.getString("tj_jabatan");
                datagaji[x][4]=kon.rs.getString("tj_keluarga");
                datagaji[x][5]=kon.rs.getString("uang_makan");
                datagaji[x][6]=kon.rs.getString("lembur");
                x++;
            }
            tbgaji.setModel(new DefaultTableModel(datagaji,label));
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void BacaTabelGajiCari(){
        try{
            String sql="select * from gaji where nama_jabatan like '%" +tcari.getText()+ "%'";
            kon.rs=kon.st.executeQuery(sql);
            ResultSetMetaData m=kon.rs.getMetaData();
            int kolom=m.getColumnCount();
            int baris=0;
            while(kon.rs.next()){
                baris=kon.rs.getRow();
            }
            datagaji=new Object[baris][kolom];
            int x=0;
            kon.rs.beforeFirst();
            while(kon.rs.next()){
                datagaji[x][0]=kon.rs.getString("kd_jabatan");
                datagaji[x][1]=kon.rs.getString("nama_jabatan");
                datagaji[x][2]=kon.rs.getString("gaji_pokok");
                datagaji[x][3]=kon.rs.getString("tj_jabatan");
                datagaji[x][4]=kon.rs.getString("tj_keluarga");
                datagaji[x][5]=kon.rs.getString("uang_makan");
                datagaji[x][6]=kon.rs.getString("lembur");
                x++;
            }
            tbgaji.setModel(new DefaultTableModel(datagaji,label));
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void SetTabel(){
        int row=tbgaji.getSelectedRow();
        tkode.setText((String)tbgaji.getValueAt(row, 0));
        tnama.setText((String)tbgaji.getValueAt(row, 1));
        tgaji.setText((String)tbgaji.getValueAt(row, 2));
        tjabatan.setText((String)tbgaji.getValueAt(row, 3));
        tkeluarga.setText((String)tbgaji.getValueAt(row, 4));
        tmakan.setText((String)tbgaji.getValueAt(row, 5));
        tlembur.setText((String)tbgaji.getValueAt(row, 6));
    }
    
    private void bersih(){
        tkode.setText("");
        tnama.setText("");
        tgaji.setText("");
        tjabatan.setText("");
        tkeluarga.setText("");
        tmakan.setText("");
        tlembur.setText("");
    }
    
    private void aktif(){
        tkode.setEnabled(true);
        tnama.setEnabled(true);
        tgaji.setEnabled(true);
        tjabatan.setEnabled(true);
        tkeluarga.setEnabled(true);
        tmakan.setEnabled(true);
        tlembur.setEnabled(true);
    }
    
    private void nonaktif(){
        tkode.setEnabled(false);
        tnama.setEnabled(false);
        tgaji.setEnabled(false);
        tjabatan.setEnabled(false);
        tkeluarga.setEnabled(false);
        tmakan.setEnabled(false);
        tlembur.setEnabled(false);
    }
    
     private void SimpanData(){
            if(tkode.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Kode Jabatan Tidak Boleh Kosong");
            }
            else if(tnama.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Nama Jabatan Tidak Boleh Kosong");
            }
            else if(tgaji.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Gaji Pokok Tidak Boleh Kosong");
            }
            else if(tjabatan.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Tunjangan Jabatan Tidak Boleh Kosong");
            }
            else if(tkeluarga.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Tunjangan Keluarga Tidak Boleh Kosong");
            }
            else if(tmakan.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Uang Makan per Hari Tidak Boleh Kosong");
            }
            else if(tlembur.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Uang Lembur per Menit Tidak Boleh Kosong");
            }
            else{
                try{
                    String sql="insert into gaji values('"+tkode.getText()+"','"+tnama.getText()+"','"+tgaji.getText()+"','"+tjabatan.getText()+"','"+tkeluarga.getText()+"','"+tmakan.getText()+"','"+tlembur.getText()+"')";
                    kon.st.executeUpdate(sql);
                    JOptionPane.showMessageDialog(null,"Data berhasil disimpan");
                    bttambah.setText("TAMBAH");
                    btkeluar.setText("KELUAR");
                    bersih();
                    nonaktif();
                    BacaTabelGaji();
                }
                catch(SQLException e){
                    JOptionPane.showMessageDialog(null, e);
                }
            }
    }
     
     private void UpdateData(){
            if(tkode.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Kode Jabatan Tidak Boleh Kosong");
            }
            else if(tnama.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Nama Jabatan Tidak Boleh Kosong");
            }
            else if(tgaji.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Gaji Pokok Tidak Boleh Kosong");
            }
            else if(tjabatan.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Tunjangan Jabatan Tidak Boleh Kosong");
            }
            else if(tkeluarga.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Tunjangan Keluarga Tidak Boleh Kosong");
            }
            else if(tmakan.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Uang Makan per Hari Tidak Boleh Kosong");
            }
            else if(tlembur.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Uang Lembur per Menit Tidak Boleh Kosong");
            }
            else{
                try{
                    String sql="update gaji set kd_jabatan='"+tkode.getText()+"',nama_jabatan='"+tnama.getText()+"',gaji_pokok='"+tgaji.getText()+"',tj_jabatan='"+tjabatan.getText()+"',tj_keluarga='"+tkeluarga.getText()+"',uang_makan='"+tmakan.getText()+"',lembur='"+tlembur.getText()+"' where kd_jabatan='"+tkode.getText()+"'";
                    kon.st.executeUpdate(sql);
                    JOptionPane.showMessageDialog(null,"Data berhasil diedit");
                    bttambah.setText("TAMBAH");
                    btkeluar.setText("KELUAR");
                    bersih();
                    nonaktif();
                    BacaTabelGaji();
                }
                catch(SQLException e){
                    JOptionPane.showMessageDialog(null, e);
                }
            }
    }
     
     private void HapusData(){
        if(JOptionPane.showConfirmDialog(this,"Yakin ingin menghapus data?","Konfirmasi",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
            try{
                String sql="delete from gaji where kd_jabatan='"+tkode.getText()+"'";
                kon.st.executeUpdate(sql);
                JOptionPane.showMessageDialog(null,"Data berhasil dihapus");
                bersih();
                BacaTabelGaji();
            }
            catch(SQLException e){
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpop = new javax.swing.JPopupMenu();
        miedit = new javax.swing.JMenuItem();
        mihapus = new javax.swing.JMenuItem();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        tkode = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        tnama = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        tjabatan = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        tgaji = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        tkeluarga = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        tmakan = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        tlembur = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        tcari = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbgaji = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        bttambah = new javax.swing.JButton();
        btkeluar = new javax.swing.JButton();

        miedit.setText("Edit");
        miedit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mieditActionPerformed(evt);
            }
        });
        jpop.add(miedit);

        mihapus.setText("Hapus");
        mihapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mihapusActionPerformed(evt);
            }
        });
        jpop.add(mihapus);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Master Gaji");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(43, 203, 186));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("INPUT DATA GAJI");

        jPanel5.setBackground(new java.awt.Color(43, 203, 186));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jPanel2.setBackground(new java.awt.Color(43, 203, 186));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Data Gaji Karyawan"));

        jLabel4.setText("Kode Jabatan");

        tkode.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tkodeKeyPressed(evt);
            }
        });

        jLabel5.setText("Nama Jabatan");

        tnama.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tnamaKeyPressed(evt);
            }
        });

        jLabel6.setText("Gaji Pokok");

        tjabatan.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tjabatanKeyPressed(evt);
            }
        });

        jLabel7.setText("Tunjangan Jabatan");

        tgaji.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tgajiKeyPressed(evt);
            }
        });

        jLabel8.setText("Tunjangan Keluarga");

        tkeluarga.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tkeluargaKeyPressed(evt);
            }
        });

        jLabel9.setText("Uang Makan per Hari");

        tmakan.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tmakanKeyPressed(evt);
            }
        });

        jLabel10.setText("Uang Lembur per Menit");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(jLabel6)
                    .addComponent(jLabel8)
                    .addComponent(jLabel5)
                    .addComponent(jLabel4)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tmakan, javax.swing.GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE)
                    .addComponent(tkeluarga)
                    .addComponent(tjabatan)
                    .addComponent(tgaji)
                    .addComponent(tnama)
                    .addComponent(tkode)
                    .addComponent(tlembur))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(tkode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(tnama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(tgaji, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jLabel7))
                    .addComponent(tjabatan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jLabel8))
                    .addComponent(tkeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(tmakan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(tlembur, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel1.setBackground(new java.awt.Color(43, 203, 186));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jLabel2.setText("Cari Nama Jabatan");

        tcari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tcariKeyTyped(evt);
            }
        });

        tbgaji.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbgaji.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbgajiMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                tbgajiMouseReleased(evt);
            }
        });
        tbgaji.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tbgajiKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(tbgaji);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 865, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(tcari, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(tcari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1)
                .addContainerGap())
        );

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("TABEL DATA GAJI");

        jPanel3.setBackground(new java.awt.Color(43, 203, 186));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        bttambah.setText("TAMBAH");
        bttambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttambahActionPerformed(evt);
            }
        });

        btkeluar.setText("KELUAR");
        btkeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btkeluarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bttambah)
                .addGap(18, 18, 18)
                .addComponent(btkeluar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bttambah)
                    .addComponent(btkeluar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 319, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(52, 52, 52)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 875, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(104, 104, 104)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bttambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttambahActionPerformed
    if(bttambah.getText().equals("TAMBAH")){
        bttambah.setText("SIMPAN");
        btkeluar.setText("BATAL");
        bersih();
        aktif();
        tkode.requestFocus();
    }
    else if(bttambah.getText().equals("SIMPAN")){
        SimpanData();
        BacaTabelGaji();
    }
    else if(bttambah.getText().equals("UPDATE")){
        UpdateData();
        BacaTabelGaji();
    }
    }//GEN-LAST:event_bttambahActionPerformed

    private void btkeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btkeluarActionPerformed
    if(btkeluar.getText().equals("KELUAR")){
        dispose();
    }
    else if(btkeluar.getText().equals("BATAL")){
        bersih();
        nonaktif();
        btkeluar.setText("KELUAR");
        bttambah.setText("TAMBAH");
    }
    }//GEN-LAST:event_btkeluarActionPerformed

    private void tkodeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tkodeKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        try{
            String sql="select * from gaji where kd_jabatan='"+tkode.getText()+"'";
            kon.rs=kon.st.executeQuery(sql);
            if(kon.rs.next()){
                tkode.setEnabled(false);
                tnama.setEnabled(false);
                tkode.setText(kon.rs.getString("kd_jabatan"));
                tnama.setText(kon.rs.getString("nama_jabatan"));
                tgaji.setText(kon.rs.getString("gaji_pokok"));
                tjabatan.setText(kon.rs.getString("tj_jabatan"));
                tkeluarga.setText(kon.rs.getString("tj_keluarga"));
                tmakan.setText(kon.rs.getString("uang_makan"));
                tlembur.setText(kon.rs.getString("lembur"));
                bttambah.setText("UPDATE");
            } else{
                tgaji.requestFocus();
            }
        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    }//GEN-LAST:event_tkodeKeyPressed

    private void tcariKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcariKeyTyped
    kon.setKoneksi();
    BacaTabelGajiCari();
    }//GEN-LAST:event_tcariKeyTyped

    private void tbgajiKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbgajiKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_BACK_SPACE){
        HapusData();
    }
    }//GEN-LAST:event_tbgajiKeyPressed

    private void tbgajiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbgajiMouseClicked
    SetTabel();
    }//GEN-LAST:event_tbgajiMouseClicked

    private void tnamaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnamaKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        tgaji.requestFocus();
    }
    }//GEN-LAST:event_tnamaKeyPressed

    private void tgajiKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tgajiKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        tjabatan.requestFocus();
    }
    }//GEN-LAST:event_tgajiKeyPressed

    private void tjabatanKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tjabatanKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        tkeluarga.requestFocus();
    }
    }//GEN-LAST:event_tjabatanKeyPressed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
    nonaktif();
    BacaTabelGaji();
    }//GEN-LAST:event_formWindowOpened

    private void tmakanKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tmakanKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        tlembur.requestFocus();
    }
    }//GEN-LAST:event_tmakanKeyPressed

    private void tbgajiMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbgajiMouseReleased
    if(evt.isPopupTrigger()){
        JTable source = (JTable)evt.getSource();
        int row = source.rowAtPoint(evt.getPoint());
        int column = source.columnAtPoint(evt.getPoint());
        if(! source.isRowSelected(row))
            source.changeSelection(row, column, false, false);
        jpop.show(evt.getComponent(), evt.getX(), evt.getY());
    }
    }//GEN-LAST:event_tbgajiMouseReleased

    private void mieditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mieditActionPerformed
    aktif();
    bersih();
    SetTabel();
    tkode.setEnabled(false);
    tnama.setEnabled(false);
    tgaji.requestFocus();
    bttambah.setEnabled(true);
    bttambah.setText("UPDATE");
    btkeluar.setText("BATAL");
    }//GEN-LAST:event_mieditActionPerformed

    private void mihapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mihapusActionPerformed
    HapusData();
    }//GEN-LAST:event_mihapusActionPerformed

    private void tkeluargaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tkeluargaKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        tmakan.requestFocus();
    }
    }//GEN-LAST:event_tkeluargaKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(master_gaji.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(master_gaji.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(master_gaji.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(master_gaji.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new master_gaji().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btkeluar;
    private javax.swing.JButton bttambah;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu jpop;
    private javax.swing.JMenuItem miedit;
    private javax.swing.JMenuItem mihapus;
    private javax.swing.JTable tbgaji;
    private javax.swing.JTextField tcari;
    private javax.swing.JTextField tgaji;
    private javax.swing.JTextField tjabatan;
    private javax.swing.JTextField tkeluarga;
    private javax.swing.JTextField tkode;
    private javax.swing.JTextField tlembur;
    private javax.swing.JTextField tmakan;
    private javax.swing.JTextField tnama;
    // End of variables declaration//GEN-END:variables
}
