/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplikasi_penggajian;
import java.awt.event.KeyEvent;
import java.sql.*;
import java.text.*;
import java.util.Date;
import java.util.logging.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Baihirul Fuat
 */
public class master_karyawan extends javax.swing.JFrame {
koneksi kon = new koneksi();
private Object [][] datakaryawan=null;
private String[] label={"NIP","Nama Karyawan","Alamat","No Telp","Tempat Lahir","Tanggal Lahir","Jenis Kelamin","Pendidikan Akhir","Agama","Jabatan","Tanggal Masuk","Status Pernikahan"};
String lahir,masuk;
    /**
     * Creates new form data_karyawan
     */
    public master_karyawan() {
        initComponents();
        kon.setKoneksi();
        BacaTabelKaryawan();
        ComboJabatan();
    }
    
    private void BacaTabelKaryawan(){
        try{
            String sql="select * from karyawan order by nip";
            kon.rs=kon.st.executeQuery(sql);
            ResultSetMetaData m=kon.rs.getMetaData();
            int kolom=m.getColumnCount();
            int baris=0;
            while(kon.rs.next()){
                baris=kon.rs.getRow();
            }
            datakaryawan=new Object[baris][kolom];
            int x=0;
            kon.rs.beforeFirst();
            while(kon.rs.next()){
                datakaryawan[x][0]=kon.rs.getString("nip");
                datakaryawan[x][1]=kon.rs.getString("nama_karyawan");
                datakaryawan[x][2]=kon.rs.getString("alamat");
                datakaryawan[x][3]=kon.rs.getString("no_telp");
                datakaryawan[x][4]=kon.rs.getString("tempat_lahir");
                datakaryawan[x][5]=kon.rs.getString("tgl_lahir");
                datakaryawan[x][6]=kon.rs.getString("jenis_kelamin");
                datakaryawan[x][7]=kon.rs.getString("pendidikan_akhir");
                datakaryawan[x][8]=kon.rs.getString("agama");
                datakaryawan[x][9]=kon.rs.getString("jabatan");
                datakaryawan[x][10]=kon.rs.getString("tgl_masuk");
                datakaryawan[x][11]=kon.rs.getString("status_pernikahan");
                x++;
            }
            tbkaryawan.setModel(new DefaultTableModel(datakaryawan,label));
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void BacaTabelKaryawanCari(){
        try{
            String sql="select * from karyawan where nama_karyawan like '%" +tcari.getText()+ "%'";
            kon.rs=kon.st.executeQuery(sql);
            ResultSetMetaData m=kon.rs.getMetaData();
            int kolom=m.getColumnCount();
            int baris=0;
            while(kon.rs.next()){
                baris=kon.rs.getRow();
            }
            datakaryawan=new Object[baris][kolom];
            int x=0;
            kon.rs.beforeFirst();
            while(kon.rs.next()){
                datakaryawan[x][0]=kon.rs.getString("nip");
                datakaryawan[x][1]=kon.rs.getString("nama_karyawan");
                datakaryawan[x][2]=kon.rs.getString("alamat");
                datakaryawan[x][3]=kon.rs.getString("no_telp");
                datakaryawan[x][4]=kon.rs.getString("tempat_lahir");
                datakaryawan[x][5]=kon.rs.getString("tgl_lahir");
                datakaryawan[x][6]=kon.rs.getString("jenis_kelamin");
                datakaryawan[x][7]=kon.rs.getString("pendidikan_akhir");
                datakaryawan[x][8]=kon.rs.getString("agama");
                datakaryawan[x][9]=kon.rs.getString("jabatan");
                datakaryawan[x][10]=kon.rs.getString("tgl_masuk");
                datakaryawan[x][11]=kon.rs.getString("status_pernikahan");
                x++;
            }
            tbkaryawan.setModel(new DefaultTableModel(datakaryawan,label));
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void SetTabel(){
        int i = tbkaryawan.getSelectedRow();
    if (i==-1){
        return;
    }
    try{
        String NIP = (String) tbkaryawan.getValueAt(i, 0);
        tnip.setText(NIP);
        String Nm_Karyawan = (String) tbkaryawan.getValueAt(i, 1);
        tnama.setText(Nm_Karyawan);
        String Alamat = (String) tbkaryawan.getValueAt(i, 2);
        talamat.setText(Alamat);
        String No_Telp = (String) tbkaryawan.getValueAt(i, 3);
        ttelp.setText(No_Telp);
        String Tempat_Lahir = (String) tbkaryawan.getValueAt(i, 4);
        ttempat.setText(Tempat_Lahir);
        Date Tgl_Lahir = new SimpleDateFormat("yyyy-MM-dd").parse((String)tbkaryawan.getValueAt(i, 5));
        clahir.setDate(Tgl_Lahir);
        String Jenis_Kelamin = (String) tbkaryawan.getValueAt(i, 6);
        cbjeniskelamin.setSelectedItem(Jenis_Kelamin);
        String Pendidikan_Akhir = (String) tbkaryawan.getValueAt(i, 7);
        cbpendidikan.setSelectedItem(Pendidikan_Akhir);
        String Agama = (String) tbkaryawan.getValueAt(i, 8);
        tagama.setText(Agama);
        String Jabatan = (String) tbkaryawan.getValueAt(i, 9);
        cbjabatan.setSelectedItem(Jabatan);
        Date Tgl_Masuk = new SimpleDateFormat("yyyy-MM-dd").parse((String)tbkaryawan.getValueAt(i, 10));
        cmasuk.setDate(Tgl_Masuk);
        String Status_Pernikahan = (String) tbkaryawan.getValueAt(i, 11);
        cbstatus.setSelectedItem(Status_Pernikahan);
    }catch (ParseException ex) {
            Logger.getLogger(master_karyawan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void bersih(){
        tnip.setText("");
        tnama.setText("");
        talamat.setText("");
        ttelp.setText("");
        ttempat.setText("");
        clahir.setDate(null);
        cbjeniskelamin.setSelectedItem("= PILIH =");
        cbpendidikan.setSelectedItem("= PILIH =");
        tagama.setText("");
        cbjabatan.setSelectedItem("= PILIH =");
        cmasuk.setDate(null);
        cbstatus.setSelectedItem("= PILIH =");
    }
    
    private void aktif(){
        tnip.setEnabled(true);
        tnama.setEnabled(true);
        talamat.setEnabled(true);
        ttelp.setEnabled(true);
        ttempat.setEnabled(true);
        clahir.setEnabled(true);
        cbjeniskelamin.setEnabled(true);
        cbpendidikan.setEnabled(true);
        tagama.setEnabled(true);
        cbjabatan.setEnabled(true);
        cmasuk.setEnabled(true);
        cbstatus.setEnabled(true);
    }
    
    private void nonaktif(){
        tnip.setEnabled(false);
        tnama.setEnabled(false);
        talamat.setEnabled(false);
        ttelp.setEnabled(false);
        ttempat.setEnabled(false);
        clahir.setEnabled(false);
        cbjeniskelamin.setEnabled(false);
        cbpendidikan.setEnabled(false);
        tagama.setEnabled(false);
        cbjabatan.setEnabled(false);
        cmasuk.setEnabled(false);
        cbstatus.setEnabled(false);
    }
    
    private void FormatTanggal(){
        try{
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        lahir = simpleDateFormat.format(clahir.getDate());
        masuk = simpleDateFormat.format(cmasuk.getDate());
        }
        catch(Exception e){
            
        }
    }
    
    private void SimpanData(){
        FormatTanggal();
        String Lahir = ((JTextField)clahir.getDateEditor().getUiComponent()).getText();
        String Masuk = ((JTextField)cmasuk.getDateEditor().getUiComponent()).getText();
        if(tnip.getText().equals("")){
            JOptionPane.showMessageDialog(null,"NIP Tidak Boleh Kosong");
        }
        else if(tnama.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Nama Karyawan Tidak Boleh Kosong");
        }
        else if(talamat.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Alamat Tidak Boleh Kosong");
        }
        else if(ttelp.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Nomor Telepon Tidak Boleh Kosong");
        }
        else if(ttempat.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Tempat Lahir Tidak Boleh Kosong");
        }
        else if(Lahir.equals("")){
            JOptionPane.showMessageDialog(null,"Tanggal Lahir Tidak Boleh Kosong");
        }
        else if(cbjeniskelamin.getSelectedItem().toString().equals("= PILIH =")){
            JOptionPane.showMessageDialog(null,"Jenis Kelamin Tidak Boleh Kosong");
        }
        else if(cbpendidikan.getSelectedItem().toString().equals("= PILIH =")){
            JOptionPane.showMessageDialog(null,"Pendidikan Akhir Tidak Boleh Kosong");
        }
        else if(tagama.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Agama Tidak Boleh Kosong");
        }
        else if(cbjabatan.getSelectedItem().toString().equals("= PILIH =")){
            JOptionPane.showMessageDialog(null,"Jabatan Tidak Boleh Kosong");
        }
        else if(Masuk.equals("")){
            JOptionPane.showMessageDialog(null,"Tanggal Masuk Tidak Boleh Kosong");
        }
        else if(cbstatus.getSelectedItem().toString().equals("= PILIH =")){
            JOptionPane.showMessageDialog(null,"Status Pernikahan Tidak Boleh Kosong");
        }
        else{
            try{
                String sql="insert into karyawan values('"+tnip.getText()+"','"+tnama.getText()+"','"+talamat.getText()+"','"+ttelp.getText()+"','"+ttempat.getText()+"','"+lahir+"','"+cbjeniskelamin.getSelectedItem().toString()+"','"+cbpendidikan.getSelectedItem().toString()+"','"+tagama.getText()+"','"+cbjabatan.getSelectedItem().toString()+"','"+masuk+"','"+cbstatus.getSelectedItem().toString()+"')";
                kon.st.executeUpdate(sql);
                JOptionPane.showMessageDialog(null,"Data berhasil disimpan");
                bttambah.setText("TAMBAH");
                btkeluar.setText("KELUAR");
                bersih();
                nonaktif();
                BacaTabelKaryawan();
            }
            catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
            }
        }
    }
    
    private void UpdateData(){
        FormatTanggal();
        String Lahir = ((JTextField)clahir.getDateEditor().getUiComponent()).getText();
        String Masuk = ((JTextField)cmasuk.getDateEditor().getUiComponent()).getText();
        if(tnip.getText().equals("")){
            JOptionPane.showMessageDialog(null,"NIP Tidak Boleh Kosong");
        }
        else if(tnama.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Nama Karyawan Tidak Boleh Kosong");
        }
        else if(talamat.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Alamat Tidak Boleh Kosong");
        }
        else if(ttelp.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Nomor Telepon Tidak Boleh Kosong");
        }
        else if(ttempat.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Tempat Lahir Tidak Boleh Kosong");
        }
        else if(Lahir.equals("")){
            JOptionPane.showMessageDialog(null,"Tanggal Lahir Tidak Boleh Kosong");
        }
        else if(cbjeniskelamin.getSelectedItem().toString().equals("= PILIH =")){
            JOptionPane.showMessageDialog(null,"Jenis Kelamin Tidak Boleh Kosong");
        }
        else if(cbpendidikan.getSelectedItem().toString().equals("= PILIH =")){
            JOptionPane.showMessageDialog(null,"Pendidikan Akhir Tidak Boleh Kosong");
        }
        else if(tagama.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Agama Tidak Boleh Kosong");
        }
        else if(cbjabatan.getSelectedItem().toString().equals("= PILIH =")){
            JOptionPane.showMessageDialog(null,"Jabatan Tidak Boleh Kosong");
        }
        else if(Masuk.equals("")){
            JOptionPane.showMessageDialog(null,"Tanggal Masuk Tidak Boleh Kosong");
        }
        else if(cbstatus.getSelectedItem().toString().equals("= PILIH =")){
            JOptionPane.showMessageDialog(null,"Status Pernikahan Tidak Boleh Kosong");
        }
        else{
            try{
                String sql="update karyawan set nip='"+tnip.getText()+"',nama_karyawan='"+tnama.getText()+"',alamat='"+talamat.getText()+"',no_telp='"+ttelp.getText()+"',tempat_lahir='"+ttempat.getText()+"',tgl_lahir='"+lahir+"',jenis_kelamin='"+cbjeniskelamin.getSelectedItem().toString()+"',pendidikan_akhir='"+cbpendidikan.getSelectedItem().toString()+"',agama='"+tagama.getText()+"',jabatan='"+cbjabatan.getSelectedItem().toString()+"',tgl_masuk='"+masuk+"',status_pernikahan='"+cbstatus.getSelectedItem().toString()+"' where nip='"+tnip.getText()+"'";
                kon.st.executeUpdate(sql);
                JOptionPane.showMessageDialog(null,"Data berhasil diedit");
                bttambah.setText("TAMBAH");
                btkeluar.setText("KELUAR");
                bersih();
                nonaktif();
                BacaTabelKaryawan();
            }
            catch(SQLException e){
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }
    
    private void HapusData(){
        if(JOptionPane.showConfirmDialog(this,"Yakin ingin menghapus data?","Konfirmasi",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
            try{
                String sql="delete from karyawan where nip='"+tnip.getText()+"'";
                kon.st.executeUpdate(sql);
                JOptionPane.showMessageDialog(null,"Data berhasil dihapus");
                bersih();
                BacaTabelKaryawan();
            }
            catch(SQLException e){
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }
    
    private void ComboJabatan(){
        cbjabatan.addItem("= PILIH =");
        cbjabatan.setSelectedItem("= PILIH =");
        try {
        String sql = "select * from gaji";
        kon.rs=kon.st.executeQuery(sql);
        while (kon.rs.next()) {
        cbjabatan.addItem(kon.rs.getString("nama_jabatan"));
        }
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Terjadi Kesalahan");
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpop = new javax.swing.JPopupMenu();
        miedit = new javax.swing.JMenuItem();
        mihapus = new javax.swing.JMenuItem();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        ttempat = new javax.swing.JTextField();
        tnip = new javax.swing.JTextField();
        tnama = new javax.swing.JTextField();
        ttelp = new javax.swing.JTextField();
        clahir = new com.toedter.calendar.JDateChooser();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        cbpendidikan = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        tagama = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        cbjabatan = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        cmasuk = new com.toedter.calendar.JDateChooser();
        jLabel14 = new javax.swing.JLabel();
        cbstatus = new javax.swing.JComboBox<>();
        cbjeniskelamin = new javax.swing.JComboBox<>();
        jLabel15 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        talamat = new javax.swing.JTextPane();
        jPanel3 = new javax.swing.JPanel();
        bttambah = new javax.swing.JButton();
        btkeluar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        tcari = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbkaryawan = new javax.swing.JTable();

        miedit.setText("Edit");
        miedit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mieditActionPerformed(evt);
            }
        });
        jpop.add(miedit);

        mihapus.setText("Hapus");
        mihapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mihapusActionPerformed(evt);
            }
        });
        jpop.add(mihapus);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Master Karyawan");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(43, 203, 186));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("INPUT DATA KARYAWAN");

        jPanel5.setBackground(new java.awt.Color(43, 203, 186));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jPanel2.setBackground(new java.awt.Color(43, 203, 186));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Data Karyawan"));

        jLabel4.setText("NIP");

        jLabel5.setText("Nama Karyawan");

        jLabel6.setText("Alamat");

        jLabel7.setText("No Telp");

        jLabel8.setText("Tempat Lahir");

        ttempat.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                ttempatKeyPressed(evt);
            }
        });

        tnip.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tnipKeyPressed(evt);
            }
        });

        tnama.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tnamaKeyPressed(evt);
            }
        });

        ttelp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                ttelpKeyPressed(evt);
            }
        });

        clahir.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                clahirPropertyChange(evt);
            }
        });

        jLabel9.setText("Jenis Kelamin");

        jLabel10.setText("Pendidikan Akhir");

        cbpendidikan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "= PILIH =", "Tidak Ada", "SD", "SMP", "SMA/SMK", "D1", "D2", "D3", "D4", "S1", "S2", "S3" }));
        cbpendidikan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbpendidikanActionPerformed(evt);
            }
        });

        jLabel11.setText("Agama");

        tagama.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tagamaKeyPressed(evt);
            }
        });

        jLabel12.setText("Jabatan");

        jLabel13.setText("Tanggal Masuk");

        cmasuk.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                cmasukPropertyChange(evt);
            }
        });

        jLabel14.setText("Status Pernikahan");

        cbstatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "= PILIH =", "Belum Menikah", "Menikah" }));

        cbjeniskelamin.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "= PILIH =", "Laki-laki", "Perempuan" }));
        cbjeniskelamin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbjeniskelaminActionPerformed(evt);
            }
        });

        jLabel15.setText("Tanggal Lahir");

        jScrollPane3.setViewportView(talamat);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel4)
                            .addComponent(jLabel15))
                        .addGap(27, 27, 27)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(ttempat, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ttelp, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tnip, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tnama, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(clahir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.LEADING)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addGap(18, 18, 18)
                        .addComponent(cbstatus, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addGap(34, 34, 34)
                        .addComponent(cmasuk, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(jLabel10)
                            .addComponent(jLabel9)
                            .addComponent(jLabel12))
                        .addGap(27, 27, 27)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cbpendidikan, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(tagama)
                            .addComponent(cbjeniskelamin, 0, 208, Short.MAX_VALUE)
                            .addComponent(cbjabatan, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tnip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(tnama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(ttelp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(ttempat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(clahir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(cbjeniskelamin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(cbpendidikan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(tagama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(cbjabatan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13)
                    .addComponent(cmasuk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(cbstatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel3.setBackground(new java.awt.Color(43, 203, 186));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        bttambah.setText("TAMBAH");
        bttambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttambahActionPerformed(evt);
            }
        });

        btkeluar.setText("KELUAR");
        btkeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btkeluarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bttambah)
                .addGap(18, 18, 18)
                .addComponent(btkeluar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bttambah)
                    .addComponent(btkeluar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("TABEL DATA KARYAWAN");

        jPanel1.setBackground(new java.awt.Color(43, 203, 186));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jLabel2.setText("Cari Nama Karyawan");

        tcari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tcariKeyTyped(evt);
            }
        });

        tbkaryawan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbkaryawan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbkaryawanMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                tbkaryawanMouseReleased(evt);
            }
        });
        tbkaryawan.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tbkaryawanKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(tbkaryawan);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 827, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(tcari, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(tcari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 478, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 345, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(81, 81, 81)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(44, 44, 44)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bttambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttambahActionPerformed
    if(bttambah.getText().equals("TAMBAH")){
        bttambah.setText("SIMPAN");
        btkeluar.setText("BATAL");
        bersih();
        aktif();
        tnip.requestFocus();
    }
    else if(bttambah.getText().equals("SIMPAN")){
        SimpanData();
        BacaTabelKaryawan();
    }
    else if(bttambah.getText().equals("UPDATE")){
        UpdateData();
        BacaTabelKaryawan();
    }
    }//GEN-LAST:event_bttambahActionPerformed

    private void btkeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btkeluarActionPerformed
    if(btkeluar.getText().equals("KELUAR")){
        dispose();
    }
    else if(btkeluar.getText().equals("BATAL")){
        bersih();
        nonaktif();
        btkeluar.setText("KELUAR");
        bttambah.setText("TAMBAH");
    }
    }//GEN-LAST:event_btkeluarActionPerformed

    private void tcariKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcariKeyTyped
    kon.setKoneksi();
    BacaTabelKaryawanCari();
    }//GEN-LAST:event_tcariKeyTyped

    private void tbkaryawanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbkaryawanMouseClicked
    SetTabel();
    }//GEN-LAST:event_tbkaryawanMouseClicked

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
    nonaktif();
    BacaTabelKaryawan();
    }//GEN-LAST:event_formWindowOpened

    private void tbkaryawanKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbkaryawanKeyPressed
    if(evt.getKeyCode()==KeyEvent.VK_BACK_SPACE){
        HapusData();
    }
    }//GEN-LAST:event_tbkaryawanKeyPressed

    private void cbjeniskelaminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbjeniskelaminActionPerformed
        if (cbjeniskelamin.getSelectedItem()!="= PILIH ="){
            cbpendidikan.requestFocus();
        }
    }//GEN-LAST:event_cbjeniskelaminActionPerformed

    private void cmasukPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_cmasukPropertyChange
        if (cmasuk.getDate()!=null){
            cbstatus.requestFocus();
        }
    }//GEN-LAST:event_cmasukPropertyChange

    private void tagamaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tagamaKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
            cbjabatan.requestFocus();
        }
    }//GEN-LAST:event_tagamaKeyPressed

    private void cbpendidikanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbpendidikanActionPerformed
        if (cbpendidikan.getSelectedItem()!="= PILIH ="){
            tagama.requestFocus();
        }
    }//GEN-LAST:event_cbpendidikanActionPerformed

    private void clahirPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_clahirPropertyChange
        if (clahir.getDate()!=null){
            cbjeniskelamin.requestFocus();
        }
    }//GEN-LAST:event_clahirPropertyChange

    private void ttelpKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ttelpKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
            ttempat.requestFocus();
        }
    }//GEN-LAST:event_ttelpKeyPressed

    private void tnamaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnamaKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
            talamat.requestFocus();
        }
    }//GEN-LAST:event_tnamaKeyPressed

    private void tnipKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnipKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
            try{
                String sql="select * from karyawan where nip='"+tnip.getText()+"'";
                kon.rs=kon.st.executeQuery(sql);
                if(kon.rs.next()){
                    tnip.setEnabled(false);
                    tnip.setText(kon.rs.getString("nip"));
                    tnama.setText(kon.rs.getString("nama_karyawan"));
                    talamat.setText(kon.rs.getString("alamat"));
                    ttelp.setText(kon.rs.getString("no_telp"));
                    ttempat.setText(kon.rs.getString("tempat_lahir"));
                    clahir.setDate(kon.rs.getDate("tgl_lahir"));
                    cbjeniskelamin.setSelectedItem(kon.rs.getString("jenis_kelamin"));
                    cbpendidikan.setSelectedItem(kon.rs.getString("pendidikan_akhir"));
                    tagama.setText(kon.rs.getString("agama"));
                    cbjabatan.setSelectedItem(kon.rs.getString("jabatan"));
                    cmasuk.setDate(kon.rs.getDate("tgl_masuk"));
                    cbstatus.setSelectedItem(kon.rs.getString("status_pernikahan"));
                    bttambah.setText("UPDATE");
                    tnama.requestFocus();
                } else{
                    tnama.requestFocus();
                }
            } catch (SQLException e){
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }//GEN-LAST:event_tnipKeyPressed

    private void ttempatKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ttempatKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
            clahir.getDateEditor().getUiComponent().requestFocusInWindow();
        }
    }//GEN-LAST:event_ttempatKeyPressed

    private void tbkaryawanMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbkaryawanMouseReleased
    if(evt.isPopupTrigger()){
        JTable source = (JTable)evt.getSource();
        int row = source.rowAtPoint(evt.getPoint());
        int column = source.columnAtPoint(evt.getPoint());
        if(! source.isRowSelected(row))
            source.changeSelection(row, column, false, false);
        jpop.show(evt.getComponent(), evt.getX(), evt.getY());
    }
    }//GEN-LAST:event_tbkaryawanMouseReleased

    private void mieditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mieditActionPerformed
    aktif();
    bersih();
    SetTabel();
    tnip.setEnabled(false);
    tnama.requestFocus();
    bttambah.setEnabled(true);
    bttambah.setText("UPDATE");
    btkeluar.setText("BATAL");
    }//GEN-LAST:event_mieditActionPerformed

    private void mihapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mihapusActionPerformed
    HapusData();
    }//GEN-LAST:event_mihapusActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(master_karyawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(master_karyawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(master_karyawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(master_karyawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new master_karyawan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btkeluar;
    private javax.swing.JButton bttambah;
    private javax.swing.JComboBox<String> cbjabatan;
    private javax.swing.JComboBox<String> cbjeniskelamin;
    private javax.swing.JComboBox<String> cbpendidikan;
    private javax.swing.JComboBox<String> cbstatus;
    private com.toedter.calendar.JDateChooser clahir;
    private com.toedter.calendar.JDateChooser cmasuk;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JPopupMenu jpop;
    private javax.swing.JMenuItem miedit;
    private javax.swing.JMenuItem mihapus;
    private javax.swing.JTextField tagama;
    private javax.swing.JTextPane talamat;
    private javax.swing.JTable tbkaryawan;
    private javax.swing.JTextField tcari;
    private javax.swing.JTextField tnama;
    private javax.swing.JTextField tnip;
    private javax.swing.JTextField ttelp;
    private javax.swing.JTextField ttempat;
    // End of variables declaration//GEN-END:variables
}
